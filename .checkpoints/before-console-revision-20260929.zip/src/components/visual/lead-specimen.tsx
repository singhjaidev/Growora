import { storyLead } from '@/lib/lead-story';
export function LeadSpecimen({ stage }: { stage: number }) {
  return (
    <div className="record-capsule" data-stage={stage} aria-hidden="true">
      <div className="capsule-layer" />
      <div className="capsule-face">
        <i className="capsule-identity">
          <b />
        </i>
        <div className="capsule-grooves">
          <i />
          <i />
          <i />
          <span>{stage >= 2 ? storyLead.score : 'G / 001'}</span>
        </div>
      </div>
    </div>
  );
}
