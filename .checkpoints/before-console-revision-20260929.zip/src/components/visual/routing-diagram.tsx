import { LeadSpecimen } from '@/components/visual/lead-specimen';
export function RoutingDiagram({ stage, story }: { stage: number; story: boolean }) {
  return (
    <div className={`spatial-fallback${story ? ' in-story' : ''}`} data-stage={stage}>
      <svg
        className="spatial-fallback-desktop"
        viewBox="0 0 1440 820"
        fill="none"
        aria-hidden="true"
      >
        <g strokeLinecap="round" strokeLinejoin="round">
          <path
            d="M-100 685 C170 700 155 390 425 466 S640 625 870 436 L1120 322 L1500 298"
            stroke="#c4c7d1"
            strokeWidth="66"
            transform="translate(0 24)"
          />
          <path
            d="M870 436 Q1000 486 1150 490 L1530 480 M870 436 Q975 680 1220 709 L1500 723"
            stroke="#a7aebb"
            strokeWidth="28"
            transform="translate(0 12)"
          />
          <path
            d="M870 436 Q1000 486 1150 490 L1530 480 M870 436 Q975 680 1220 709 L1500 723"
            stroke="#d5d9e3"
            strokeWidth="24"
          />
          <path
            d="M-100 685 C170 700 155 390 425 466 S640 625 870 436 L1120 322 L1500 298"
            stroke="#192c72"
            strokeWidth="57"
            transform="translate(0 12)"
          />
          <path
            d="M-100 685 C170 700 155 390 425 466 S640 625 870 436 L1120 322 L1500 298"
            stroke="#4e63d9"
            strokeWidth="52"
          />
          <path
            d="M-100 685 C170 700 155 390 425 466 S640 625 870 436 L1120 322 L1500 298"
            stroke="#cad4ff"
            strokeWidth="2"
          />
        </g>
        <g transform="translate(470 465) rotate(18)">
          <path
            d="M-34 -32V-72M-12 -30V-86M10 -28V-100M32 -26V-114"
            stroke="#848d9e"
            strokeWidth="10"
          />
          <path d="M-34 36V5M-12 38V-8M10 40V-20M32 42V-30" stroke="#fbfbf7" strokeWidth="10" />
        </g>
        <g transform="translate(750 530) rotate(-25)">
          <path d="M0 0H160" stroke="#c1c7d3" strokeWidth="25" />
          <path d="M0 -7H160" stroke="#f8f7f3" strokeWidth="20" />
          {Array.from({ length: 17 }, (_, i) => (
            <path key={i} d={`M${i * 10} -14v${i % 4 ? 7 : 13}`} stroke="#4e5565" />
          ))}
          <path d="M146 -26V12" stroke="#d6a25e" strokeWidth="5" />
        </g>
      </svg>
      <svg className="spatial-fallback-mobile" viewBox="0 0 350 330" fill="none" aria-hidden="true">
        <path
          d="M-55 219 C35 222 32 88 128 120 S198 222 227 141 Q247 94 393 106"
          stroke="#cad0da"
          strokeWidth="34"
          transform="translate(0 15)"
        />
        <path
          d="M227 141 Q265 219 400 201 M227 141 Q237 288 375 290"
          stroke="#b7bfcc"
          strokeWidth="17"
          transform="translate(0 8)"
        />
        <path
          d="M227 141 Q265 219 400 201 M227 141 Q237 288 375 290"
          stroke="#d4d9e4"
          strokeWidth="15"
        />
        <path
          d="M-55 219 C35 222 32 88 128 120 S198 222 227 141 Q247 94 393 106"
          stroke="#1e326e"
          strokeWidth="32"
          transform="translate(0 8)"
        />
        <path
          d="M-55 219 C35 222 32 88 128 120 S198 222 227 141 Q247 94 393 106"
          stroke="#4b60cd"
          strokeWidth="29"
        />
        <path
          d="M-55 219 C35 222 32 88 128 120 S198 222 227 141 Q247 94 393 106"
          stroke="#d8dffd"
          strokeWidth="1"
        />
        <g transform="translate(92 116) rotate(16)">
          <path d="M-17 -10V-43M0 -8V-50M17 -6V-57" stroke="#8e97a7" strokeWidth="6" />
          <path d="M-17 22V9M0 24V4M17 26V-1" stroke="#fcfaf7" strokeWidth="6" />
        </g>
        <g transform="translate(137 225) rotate(-12)">
          <path d="M0 0H100" stroke="#b8bfcc" strokeWidth="16" />
          <path d="M0 -5H100" stroke="#f8f7f3" strokeWidth="14" />
          {Array.from({ length: 11 }, (_, i) => (
            <path key={i} d={`M${i * 10} -10v${i % 5 ? 5 : 10}`} stroke="#555e6f" />
          ))}
          <path d="M91 -19V8" stroke="#d6a25e" strokeWidth="4" />
        </g>
      </svg>
      <LeadSpecimen stage={stage} />
      <div className="mobile-world-label">
        <span>
          {story
            ? [
                'INCOMING SIGNAL',
                'CONTEXT RESOLVED',
                'INTENT INDEX',
                'PRIORITY ROUTE',
                'NEXT ACTION',
                'OPPORTUNITY',
              ][stage]
            : 'INTENT INDEX'}
        </span>
        <strong>
          {stage >= 3 ? 'Jamie Lee' : '91'}
          {stage < 3 && <small>/100</small>}
        </strong>
        <span>
          {stage === 4
            ? '+1 day · Reminder prepared'
            : stage === 5
              ? 'Qualified · £7,500'
              : 'High intent. Clear direction.'}
        </span>
      </div>
    </div>
  );
}
