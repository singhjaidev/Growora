'use client';
import dynamic from 'next/dynamic';
import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUpRight, Pause, Play, RotateCcw, ArrowRight } from 'lucide-react';
import { ButtonLink, tabKeyboard } from '@/components/ui';
import { storyLead, storyStages, storyChapters, type SceneFrame } from '@/lib/lead-story';
import { RoutingDiagram } from '@/components/visual/routing-diagram';
import { JourneyTranscript } from '@/components/marketing/lead-journey';
const Engine = dynamic(() => import('@/components/three/lead-engine'), { ssr: false });
const TRAVEL = 1900;
const ENABLE_STORY = true;

export function Hero() {
  const host = useRef<HTMLElement>(null);
  const surface = useRef<HTMLDivElement>(null);
  const controls = useRef<{
    pause: () => void;
    resume: () => void;
    replay: () => void;
    select: (index: number) => void;
    follow: () => void;
  }>({ pause: () => {}, resume: () => {}, replay: () => {}, select: () => {}, follow: () => {} });
  const [clock] = useState(() => {
    let frame: SceneFrame = {
      progress: 0,
      intro: 1,
      time: 0,
      story: false,
      pointerX: 0,
      pointerY: 0,
    };
    const listeners = new Set<(value: SceneFrame) => void>();
    return {
      getSnapshot: () => frame,
      subscribe: (listener: (value: SceneFrame) => void) => {
        listeners.add(listener);
        return () => {
          listeners.delete(listener);
        };
      },
      publish: (value: SceneFrame) => {
        frame = value;
        listeners.forEach((listener) => listener(value));
      },
    };
  });
  const [show3d, setShow3d] = useState(false);
  const [ready, setReady] = useState(false);
  const [paused, setPaused] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [story, setStory] = useState(false);
  const [manual, setManual] = useState(false);
  const [stage, setStage] = useState(0);
  const [resolved, setResolved] = useState(true);
  useEffect(() => {
    const element = host.current;
    const panel = surface.current;
    if (!element || !panel) return;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const desktop = matchMedia('(min-width: 1024px) and (min-height: 820px)');
    const connection = (navigator as Navigator & { connection?: { saveData?: boolean } })
      .connection;
    let visible = false,
      stopped = false,
      disposed = false,
      eligible = false,
      override = false,
      initialized = false;
    let raf = 0,
      timer = 0,
      previous = 0,
      elapsed = 0,
      idleTime = 0,
      start = 0,
      target = 0,
      current = 0;
    let pointerX = 0,
      pointerY = 0,
      smoothX = 0,
      smoothY = 0;
    let isStory = false,
      stageNow = 0,
      resolution = true;
    const paint = (intro: number) => {
      const index = Math.min(5, Math.floor(current * 6));
      if (stageNow !== index) {
        stageNow = index;
        setStage(index);
      }
      if (resolution !== intro >= 0.6) {
        resolution = intro >= 0.6;
        setResolved(resolution);
      }
      panel.style.setProperty('--story-progress', String(current));
      panel.style.setProperty('--intro-progress', String(intro));
      panel.style.setProperty('--lead-arrival', `${isStory ? 0 : (1 - intro) * -180}px`);
      panel.style.setProperty('--lead-x', `${current * 135}px`);
      panel.style.setProperty('--lead-y', `${current * -70}px`);
      panel.style.setProperty(
        '--follow-progress',
        String(Math.max(0, Math.min(1, (current - 0.66) / 0.17))),
      );
      panel.dataset.follow = String(
        Math.min(3, Math.floor(Math.max(0, (current - 0.66) / 0.17) * 4)),
      );
      clock.publish({
        progress: current,
        intro,
        time: idleTime,
        story: isStory,
        pointerX: smoothX,
        pointerY: smoothY,
      });
    };
    const active = () => visible && !document.hidden && !stopped && !reduced.matches;
    const schedule = () => {
      if (!raf && active()) raf = requestAnimationFrame(tick);
    };
    const tick = (now: number) => {
      raf = 0;
      if (!active()) return;
      const delta = previous ? Math.min(50, now - previous) : 16;
      previous = now;
      elapsed = Math.min(2900, elapsed + delta);
      idleTime += delta / 1000;
      // Time-based damping. Scroll remains entirely native.
      const damping = 1 - Math.exp(-delta / 110);
      current += (target - current) * damping;
      smoothX += (pointerX - smoothX) * damping;
      smoothY += (pointerY - smoothY) * damping;
      if (Math.abs(target - current) < 0.0002) current = target;
      paint(elapsed / 2900);
      if (
        elapsed < 2900 ||
        Math.abs(target - current) > 0.0002 ||
        Math.abs(pointerX - smoothX) > 0.001 ||
        Math.abs(pointerY - smoothY) > 0.001
      )
        schedule();
      else if (desktop.matches) {
        // Restrained 24fps idle surface movement; no background/offscreen work.
        timer = window.setTimeout(() => {
          timer = 0;
          schedule();
        }, 1000 / 24);
      }
    };
    const readScroll = () => {
      if (!eligible || override) return;
      const next = Math.max(0, Math.min(1, (window.scrollY - start) / TRAVEL));
      target = next;
      const nextStory = next > 0.025;
      if (nextStory !== isStory) {
        isStory = nextStory;
        setStory(nextStory);
      }
      if (reduced.matches || stopped) {
        current = target;
        paint(1);
      } else schedule();
    };
    const measure = () => {
      eligible = ENABLE_STORY && desktop.matches && !reduced.matches;
      setPinned(eligible);
      start = element.getBoundingClientRect().top + window.scrollY - 80;
      readScroll();
      if (!initialized) {
        initialized = true;
        if (target > 0.025) {
          current = target;
          elapsed = 2900;
          paint(1);
        }
      }
    };
    const sync = () => {
      cancelAnimationFrame(raf);
      window.clearTimeout(timer);
      raf = 0;
      timer = 0;
      previous = 0;
      if (reduced.matches) {
        elapsed = 2900;
        current = target;
        smoothX = smoothY = 0;
        paint(1);
      }
      setShow3d(
        (old) => desktop.matches && !reduced.matches && !connection?.saveData && (old || visible),
      );
      measure();
      schedule();
    };
    controls.current = {
      pause: () => {
        stopped = true;
        sync();
      },
      resume: () => {
        stopped = false;
        sync();
      },
      replay: () => {
        elapsed = 0;
        stopped = false;
        sync();
      },
      select: (index) => {
        override = true;
        setManual(true);
        isStory = true;
        setStory(true);
        target = (index + 0.55) / 6;
        if (reduced.matches || stopped || !desktop.matches) {
          current = target;
          paint(1);
        } else schedule();
      },
      follow: () => {
        override = false;
        setManual(false);
        readScroll();
      },
    };
    const onPointer = (event: PointerEvent) => {
      if (!desktop.matches || reduced.matches) return;
      pointerX = (event.clientX / innerWidth - 0.5) * 2;
      pointerY = (event.clientY / innerHeight - 0.5) * 2;
      schedule();
    };
    const onLeave = () => {
      pointerX = 0;
      pointerY = 0;
      schedule();
    };
    const observer = new IntersectionObserver(
      ([entry]) => {
        visible = entry.isIntersecting;
        if (!visible && override && eligible) {
          override = false;
          setManual(false);
        }
        sync();
      },
      { threshold: 0.01 },
    );
    observer.observe(panel);
    window.addEventListener('scroll', readScroll, { passive: true });
    window.addEventListener('resize', measure);
    panel.addEventListener('pointermove', onPointer);
    panel.addEventListener('pointerleave', onLeave);
    reduced.addEventListener('change', sync);
    desktop.addEventListener('change', sync);
    document.addEventListener('visibilitychange', sync);
    void document.fonts.ready.then(() => {
      if (!disposed) measure();
    });
    paint(reduced.matches ? 1 : 0);
    measure();
    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      clearTimeout(timer);
      observer.disconnect();
      window.removeEventListener('scroll', readScroll);
      window.removeEventListener('resize', measure);
      panel.removeEventListener('pointermove', onPointer);
      panel.removeEventListener('pointerleave', onLeave);
      reduced.removeEventListener('change', sync);
      desktop.removeEventListener('change', sync);
      document.removeEventListener('visibilitychange', sync);
    };
  }, [clock]);
  return (
    <section
      ref={host}
      className={`spatial-experience${pinned ? ' is-pinned' : ''}`}
      id="workflow"
      aria-label="Follow one opportunity through Growora"
      style={{ '--scroll-travel': `${TRAVEL}px` } as React.CSSProperties}
    >
      <noscript><style>{`section.spatial-experience .spatial-runway{height:auto}section.spatial-experience .spatial-stage{position:relative;top:auto}`}</style></noscript>
      <div className="spatial-runway">
        <div
          ref={surface}
          className={`spatial-stage${story ? ' is-story' : ''}`}
          data-stage={stage}
          data-renderer={ready && show3d ? 'webgl' : 'svg'}
        >
          <div
            className="spatial-content"
            role="tabpanel"
            id="spatial-panel"
            aria-labelledby={`spatial-tab-${stage}`}
          >
            <div className="spatial-world" aria-hidden="true">
              <RoutingDiagram stage={stage} story={story} />
              {show3d && <Engine clock={clock} onReadyChange={setReady} />}
            </div>
            <div className="spatial-edition">
              <span>
                <i /> GROWORA / LEAD CONVERSION
              </span>
              <span>Less friction. More forward.</span>
            </div>
            <div className="spatial-title" aria-hidden={story}>
              <p>Good leads shouldn’t stand still.</p>
              <h1>
                Every lead.
                <br />
                <span>A way forward.</span>
              </h1>
            </div>
            <div className="spatial-introduction" aria-hidden={story}>
              <p>
                From the first hello to the right next step.
                <br />
                Capture, qualify and move opportunity forward.
              </p>
              <div>
                <ButtonLink href="#lead-demo">Try your lead</ButtonLink>
                <a
                  href={pinned ? '#story-start' : '#workflow'}
                  onClick={() => {
                    if (!pinned) controls.current.select(0);
                  }}
                >
                  Follow the journey <ArrowDown size={15} />
                </a>
              </div>
            </div>
            <div className="spatial-anchor anchor-lead" data-scene-anchor="lead">
              <span className="anchor-index">G / 001 · ILLUSTRATIVE LEAD</span>
              <strong>{storyLead.name}</strong>
              <span>
                {story ? storyChapters[stage].receipt : 'Website redesign · Northline Studio'}
              </span>
            </div>
            <div className="spatial-anchor anchor-score" data-scene-anchor="score">
              <span>INTENT INDEX</span>
              <strong>
                {resolved ? storyLead.score : '—'}
                <small>/100</small>
              </strong>
              <span>High intent. Clear direction.</span>
            </div>
            <div className="spatial-anchor anchor-route" data-scene-anchor="route">
              <span>PRIORITY ROUTE</span>
              <strong>
                Jamie Lee <ArrowUpRight size={14} />
              </strong>
            </div>
            <div className="spatial-story-copy" aria-hidden={!story}>
              <span className="story-chapter-number">
                0{stage + 1} <i>/ 06</i>
              </span>
              <p>{storyStages[stage]}</p>
              <h2>{storyChapters[stage].title}</h2>
              <div>{storyChapters[stage].description}</div>
              {stage === 1 && (
                <dl className="spatial-facts">
                  <div>
                    <dt>Company</dt>
                    <dd>
                      Northline Studio <b>✓</b>
                    </dd>
                  </div>
                  <div>
                    <dt>Budget</dt>
                    <dd>
                      £5,000–£10,000 <b>✓</b>
                    </dd>
                  </div>
                  <div>
                    <dt>Timing</dt>
                    <dd>
                      Within 30 days <b>✓</b>
                    </dd>
                  </div>
                </dl>
              )}
            </div>
            <div className="spatial-action-rail" hidden={!story || stage !== 4}>
              <span>FOLLOW-UP / SIMULATION</span>
              <ol>
                <li>
                  <i />
                  <small>Trigger</small>
                  <strong>Lead qualified</strong>
                </li>
                <li>
                  <i />
                  <small>Condition</small>
                  <strong>Budget &gt; £2,000</strong>
                </li>
                <li>
                  <i />
                  <small>Action</small>
                  <strong>Response ready</strong>
                </li>
                <li>
                  <i />
                  <small>Follow up</small>
                  <strong>+1 day reminder</strong>
                </li>
              </ol>
            </div>
            <div className="spatial-outcome" hidden={!story || stage !== 5}>
              <span>OPPORTUNITY CREATED / EXAMPLE</span>
              <div>
                <strong>Alex Morgan</strong>
                <b>£7,500</b>
              </div>
              <p>
                Qualified <i /> Jamie Lee <i /> Website redesign
              </p>
              <a href="#lead-demo">
                Now try your lead <ArrowRight size={16} />
              </a>
            </div>
          </div>
          <div className="spatial-bottom">
            <div
              className="spatial-stage-tabs"
              role="tablist"
              aria-label="Journey stages"
              onKeyDown={tabKeyboard}
            >
              {storyStages.map((name, index) => (
                <button
                  role="tab"
                  id={`spatial-tab-${index}`}
                  aria-controls="spatial-panel"
                  aria-selected={stage === index}
                  tabIndex={stage === index ? 0 : -1}
                  aria-label={`${index + 1}. ${name}`}
                  key={name}
                  onClick={() => controls.current.select(index)}
                >
                  <span>0{index + 1}</span>
                  {name}
                  <i />
                </button>
              ))}
            </div>
            <div className="spatial-controls">
              {manual && pinned ? (
                <button onClick={() => controls.current.follow()}>
                  Follow scroll <ArrowDown size={14} />
                </button>
              ) : (
                <span className="spatial-scroll-cue">
                  <ArrowDown size={14} />{' '}
                  {pinned ? 'Scroll to move it forward' : 'Choose a stage to explore'}
                </span>
              )}
              <button
                aria-label={paused ? 'Resume motion' : 'Pause motion'}
                aria-pressed={paused}
                onClick={() => {
                  if (paused) controls.current.resume();
                  else controls.current.pause();
                  setPaused(!paused);
                }}
              >
                {paused ? <Play size={14} /> : <Pause size={14} />}
              </button>
              <button
                aria-label="Replay opening"
                onClick={() => {
                  controls.current.replay();
                  setPaused(false);
                }}
              >
                <RotateCcw size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
      <div id="story-start" className="spatial-scroll-target" aria-hidden="true" />
      <JourneyTranscript />
    </section>
  );
}

