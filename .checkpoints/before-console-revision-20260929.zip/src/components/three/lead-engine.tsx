'use client';
import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { routeNodes, type SceneClock, type SceneFrame } from '@/lib/lead-story';

type Props = { clock: SceneClock; onReadyChange: (ready: boolean) => void };
const clamp = THREE.MathUtils.clamp;
const smooth = (a: number, b: number, value: number) => THREE.MathUtils.smoothstep(value, a, b);

/** A single persistent, procedural routing world. The parent owns its clock. */
export default function LeadEngine({ clock, onReadyChange }: Props) {
  const host = useRef<HTMLDivElement>(null);
  const readyCallback = useRef(onReadyChange);
  useEffect(() => {
    readyCallback.current = onReadyChange;
  }, [onReadyChange]);
  useEffect(() => {
    const element = host.current;
    if (!element) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: true,
        powerPreference: 'low-power',
      });
    } catch {
      readyCallback.current(false);
      return;
    }
    let dpr = Math.min(devicePixelRatio, 1.25);
    renderer.setPixelRatio(dpr);
    renderer.setClearColor(0xe9eaec, 0);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 0.98;
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
    renderer.shadowMap.autoUpdate = false;
    renderer.domElement.setAttribute('aria-hidden', 'true');
    element.appendChild(renderer.domElement);
    element.dataset.sceneId = crypto.randomUUID();
    let drawCount = 0;
    const scene = new THREE.Scene();
    scene.fog = new THREE.Fog(0xe9eaec, 40, 75);
    const camera = new THREE.PerspectiveCamera(37, 1, 0.1, 100);
    const ambient = new THREE.HemisphereLight(0xf5f5ff, 0x9ba0b2, 1.8);
    const key = new THREE.DirectionalLight(0xffffff, 2.7);
    key.position.set(-8, 18, 8);
    key.castShadow = true;
    key.shadow.mapSize.set(1024, 1024);
    Object.assign(key.shadow.camera, {
      left: -22,
      right: 22,
      top: 18,
      bottom: -18,
      near: 0.5,
      far: 55,
    });
    key.shadow.normalBias = 0.035;
    key.shadow.bias = -0.0004;
    key.shadow.radius = 3;
    scene.add(ambient, key);
    const pmrem = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    const environment = pmrem.fromScene(room, 0.04);
    scene.environment = environment.texture;
    scene.environmentIntensity = 0.7;
    room.dispose();
    pmrem.dispose();
    const materials = {
      blue: new THREE.MeshStandardMaterial({ color: 0x173ecb, metalness: 0.48, roughness: 0.26 }),
      side: new THREE.MeshStandardMaterial({ color: 0x172758, metalness: 0.45, roughness: 0.38 }),
      ceramic: new THREE.MeshStandardMaterial({
        color: 0xf5f3ed,
        metalness: 0.18,
        roughness: 0.28,
      }),
      metal: new THREE.MeshStandardMaterial({ color: 0xbac0cd, metalness: 0.8, roughness: 0.3 }),
      ink: new THREE.MeshStandardMaterial({ color: 0x303540, metalness: 0.35, roughness: 0.38 }),
      warm: new THREE.MeshStandardMaterial({ color: 0xe6a257, metalness: 0.48, roughness: 0.28 }),
      floor: new THREE.MeshStandardMaterial({ color: 0xe9eaec, metalness: 0.02, roughness: 0.92 }),
      quiet: new THREE.MeshStandardMaterial({ color: 0xb0b6c6, metalness: 0.55, roughness: 0.44 }),
    };
    const geometries = new Set<THREE.BufferGeometry>();
    const instanced: THREE.InstancedMesh[] = [];
    const geometry = <T extends THREE.BufferGeometry>(value: T) => {
      geometries.add(value);
      return value;
    };
    const unit = geometry(new THREE.BoxGeometry(1, 1, 1));
    function mesh(
      geo: THREE.BufferGeometry,
      material: THREE.Material,
      parent: THREE.Object3D = scene,
    ) {
      const obj = new THREE.Mesh(geo, material);
      obj.castShadow = true;
      obj.receiveShadow = true;
      parent.add(obj);
      return obj;
    }
    function rounded(w: number, d: number, h: number, radius = 0.16) {
      const x = -w / 2,
        y = -d / 2,
        r = radius;
      const s = new THREE.Shape();
      s.moveTo(x + r, y);
      s.lineTo(x + w - r, y);
      s.quadraticCurveTo(x + w, y, x + w, y + r);
      s.lineTo(x + w, y + d - r);
      s.quadraticCurveTo(x + w, y + d, x + w - r, y + d);
      s.lineTo(x + r, y + d);
      s.quadraticCurveTo(x, y + d, x, y + d - r);
      s.lineTo(x, y + r);
      s.quadraticCurveTo(x, y, x + r, y);
      const g = new THREE.ExtrudeGeometry(s, {
        depth: h,
        steps: 1,
        bevelEnabled: true,
        bevelThickness: 0.035,
        bevelSize: 0.035,
        bevelSegments: 2,
        curveSegments: 5,
      });
      g.rotateX(-Math.PI / 2);
      return geometry(g);
    }
    function curve(points: readonly (readonly number[])[]) {
      return new THREE.CatmullRomCurve3(
        points.map(([x, y, z]) => new THREE.Vector3(x, y, z)),
        false,
        'centripetal',
      );
    }
    const main = curve(routeNodes.main),
      priority = curve(routeNodes.priority),
      discovery = curve(routeNodes.discovery),
      nurture = curve(routeNodes.nurture);
    function ribbon(
      path: THREE.CatmullRomCurve3,
      width: number,
      depth: number,
      top: THREE.Material,
      side: THREE.Material,
      steps = 120,
    ) {
      const upper: number[] = [],
        walls: number[] = [];
      const verts: { left: THREE.Vector3; right: THREE.Vector3 }[] = [];
      for (let i = 0; i <= steps; i++) {
        const p = path.getPointAt(i / steps),
          t = path.getTangentAt(i / steps);
        const n = new THREE.Vector3(-t.z, 0, t.x).normalize().multiplyScalar(width / 2);
        verts.push({ left: p.clone().add(n), right: p.clone().sub(n) });
      }
      const tri = (out: number[], a: THREE.Vector3, b: THREE.Vector3, c: THREE.Vector3) =>
        out.push(a.x, a.y, a.z, b.x, b.y, b.z, c.x, c.y, c.z);
      for (let i = 0; i < steps; i++) {
        const a = verts[i],
          b = verts[i + 1];
        tri(upper, a.left, b.left, a.right);
        tri(upper, b.left, b.right, a.right);
        for (const edge of ['left', 'right'] as const) {
          const u = a[edge],
            v = b[edge],
            ub = u.clone().add(new THREE.Vector3(0, -depth, 0)),
            vb = v.clone().add(new THREE.Vector3(0, -depth, 0));
          tri(walls, u, ub, v);
          tri(walls, v, ub, vb);
        }
      }
      const make = (array: number[]) => {
        const g = geometry(new THREE.BufferGeometry());
        g.setAttribute('position', new THREE.Float32BufferAttribute(array, 3));
        g.computeVertexNormals();
        return g;
      };
      const group = new THREE.Group();
      scene.add(group);
      const surface = mesh(make(upper), top, group);
      surface.material.side = THREE.DoubleSide;
      const wall = mesh(make(walls), side, group);
      wall.material.side = THREE.DoubleSide;
      return { group, surface, wall, steps };
    }
    ribbon(main, 2.15, 0.52, materials.blue, materials.side);
    const selected = ribbon(priority, 2.15, 0.52, materials.blue, materials.side, 80);
    const alternateA = ribbon(discovery, 1.05, 0.18, materials.quiet, materials.metal, 65);
    const alternateB = ribbon(nurture, 1.05, 0.18, materials.quiet, materials.metal, 65);
    // A thin inset on the solid track gives the packet a precise register.
    const insetMain = curve(routeNodes.main.map(([x, y, z]) => [x, y + 0.012, z]));
    const insetPriority = curve(routeNodes.priority.map(([x, y, z]) => [x, y + 0.012, z]));
    ribbon(insetMain, 0.07, 0.012, materials.ceramic, materials.ceramic, 100);
    ribbon(insetPriority, 0.07, 0.012, materials.ceramic, materials.ceramic, 70);
    const ground = mesh(geometry(new THREE.PlaneGeometry(180, 180)), materials.floor);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -0.3;
    ground.castShadow = false;
    // Low, machined supports make the sweep a physical object rather than a line.
    [-0.1, 0.2, 0.47, 0.75].forEach((p) => {
      const v = main.getPointAt(Math.max(0, p));
      const foot = mesh(rounded(2.05, 1.1, 0.48, 0.18), materials.ink);
      foot.position.set(v.x, -0.28, v.z);
      foot.scale.y = Math.max(0.4, (v.y - 0.52 + 0.28) / 0.48);
      foot.rotation.y = -Math.atan2(
        main.getTangentAt(Math.max(0, p)).z,
        main.getTangentAt(Math.max(0, p)).x,
      );
    });
    const end = priority.getPointAt(1);
    const dock = new THREE.Group();
    dock.position.copy(end);
    scene.add(dock);
    mesh(rounded(3.7, 3, 0.22, 0.28), materials.side, dock).position.y = -0.25;
    mesh(rounded(3.5, 2.8, 0.1, 0.24), materials.ceramic, dock).position.y = -0.01;
    const dockStrip = mesh(rounded(0.13, 2.25, 0.025, 0.04), materials.blue, dock);
    dockStrip.position.set(1.45, 0.14, 0);
    // Qualification is a paired stack of thin information vanes, open down its centre.
    const scanner = new THREE.Group();
    const scannerPoint = main.getPointAt(0.61);
    scanner.position.copy(scannerPoint);
    scene.add(scanner);
    const tangent = main.getTangentAt(0.61);
    scanner.rotation.y = -Math.atan2(tangent.z, tangent.x);
    const vanes: THREE.Mesh[] = [];
    for (let i = 0; i < 4; i++) {
      for (const sign of [-1, 1]) {
        const vane = mesh(
          rounded(0.13, 1.05, 1.1 + i * 0.12, 0.05),
          i % 2 ? materials.ceramic : materials.metal,
          scanner,
        );
        vane.position.set((i - 1.5) * 0.53, 0.03, sign * 1.18);
        vane.rotation.z = -0.14;
        vanes.push(vane);
      }
    }
    const scannerBase = mesh(rounded(3.1, 3.6, 0.12, 0.26), materials.side, scanner);
    scannerBase.position.y = -0.28;
    // Scoring has a physical, linear scale with one moving index.
    const score = new THREE.Group();
    score.position.set(0.6, 0.75, 0.8);
    scene.add(score);
    const ruler = mesh(rounded(4.6, 0.72, 0.12, 0.12), materials.ceramic, score);
    ruler.position.z = 0.5;
    const ticks = new THREE.InstancedMesh(unit, materials.ink, 31);
    instanced.push(ticks);
    score.add(ticks);
    const tmp = new THREE.Object3D();
    for (let i = 0; i < 31; i++) {
      tmp.position.set(-2.1 + i * 0.14, 0.16, 0.5);
      tmp.scale.set(0.027, 0.025, i % 5 === 0 ? 0.43 : 0.22);
      tmp.rotation.set(0, 0, 0);
      tmp.updateMatrix();
      ticks.setMatrixAt(i, tmp.matrix);
    }
    const index = mesh(rounded(0.16, 1, 0.07, 0.045), materials.warm, score);
    index.position.set(1.72, 0.17, 0.5);
    // Layered record: ceramic cover, brushed edge, indigo identity slot and data grooves.
    const packet = new THREE.Group();
    packet.scale.setScalar(1.35);
    scene.add(packet);
    mesh(rounded(2.05, 1.36, 0.11, 0.2), materials.ink, packet).position.set(-0.055, -0.1, 0.035);
    mesh(rounded(2.05, 1.36, 0.12, 0.2), materials.metal, packet).position.y = 0.055;
    mesh(rounded(1.98, 1.29, 0.11, 0.17), materials.ceramic, packet).position.y = 0.23;
    const slot = mesh(rounded(0.47, 0.91, 0.027, 0.09), materials.blue, packet);
    slot.position.set(-0.61, 0.37, 0);
    const seal = mesh(
      geometry(new THREE.CylinderGeometry(0.085, 0.085, 0.022, 18)),
      materials.warm,
      packet,
    );
    seal.position.set(-0.61, 0.407, -0.24);
    const bars = new THREE.InstancedMesh(unit, materials.ink, 4);
    instanced.push(bars);
    packet.add(bars);
    for (let i = 0; i < 4; i++) {
      tmp.position.set(0.2, 0.369, -0.36 + i * 0.22);
      tmp.scale.set(i === 0 ? 0.88 : i === 3 ? 0.42 : 0.69, 0.025, 0.048);
      tmp.rotation.set(0, 0, 0);
      tmp.updateMatrix();
      bars.setMatrixAt(i, tmp.matrix);
    }
    packet.traverse((child) => {
      if (child instanceof THREE.Mesh) child.castShadow = false;
    });
    const pulse = mesh(rounded(0.18, 0.45, 0.015, 0.045), materials.warm);
    pulse.castShadow = false;
    const actionTicks = new THREE.InstancedMesh(unit, materials.warm, 3);
    instanced.push(actionTicks);
    scene.add(actionTicks);
    let frame = clock.getSnapshot(),
      width = 0,
      height = 0,
      visible = true,
      lost = false,
      disposed = false,
      loaded = false,
      lastRender = 0,
      slow = 0,
      samples = 0,
      total = 0;
    const parent = element.closest('.spatial-stage');
    const anchors = ['lead', 'score', 'route'].map((name) =>
      parent?.querySelector<HTMLElement>(`[data-scene-anchor="${name}"]`),
    );
    const projection = new THREE.Vector3();
    function ready(value: boolean) {
      element!.dataset.loaded = String(value);
      if (loaded !== value) {
        loaded = value;
        readyCallback.current(value);
      }
    }
    function anchor(index: number, point: THREE.Vector3, dx: number, dy: number) {
      const el = anchors[index];
      if (!el) return;
      projection.copy(point).project(camera);
      el.style.left = `${(projection.x * 0.5 + 0.5) * width + dx}px`;
      el.style.top = `${(-projection.y * 0.5 + 0.5) * height + dy}px`;
    }
    function draw(force = false) {
      if (disposed || lost || !visible || document.hidden || !width || !height) return;
      const now = performance.now();
      if (!force && slow > 1 && now - lastRender < 32) return;
      const started = now;
      const p = frame.progress;
      const story = frame.story;
      // Camera tracks the opportunity, then rises to make the branch intelligible.
      const focus = story ? smooth(0, 0.82, p) : 0;
      camera.position.set(
        10.8 + focus * 3.2 + frame.pointerX * 0.38,
        15.5 - focus * 3.4 + frame.pointerY * 0.18,
        22 - focus * 7,
      );
      const target = new THREE.Vector3(focus * 6, 0.3 + smooth(0, 0.09, p) * 2.5, -focus * 4.5);
      camera.lookAt(target);
      camera.updateMatrixWorld();
      let position: THREE.Vector3, direction: THREE.Vector3;
      if (story) {
        const t = 0.64 + smooth(0.1, 0.55, p) * 0.36;
        if (p < 0.55) {
          position = main.getPointAt(t);
          direction = main.getTangentAt(t);
        } else {
          const branch = smooth(0.55, 0.96, p);
          position = priority.getPointAt(branch);
          direction = priority.getTangentAt(branch);
        }
      } else {
        const intro = smooth(0, 0.68, frame.intro);
        const t = 0.16 + intro * 0.48;
        position = main.getPointAt(t);
        direction = main.getTangentAt(t);
      }
      position.y += 0.16 + Math.sin(frame.time * 1.1) * 0.018;
      packet.position.copy(position);
      packet.rotation.y = -Math.atan2(direction.z, direction.x);
      const qualify = story ? smooth(0.16, 0.31, p) : smooth(0.28, 0.6, frame.intro);
      vanes.forEach((v, i) => {
        v.position.y = 0.03 + Math.sin(qualify * Math.PI) * (0.16 + (i % 2) * 0.08);
        v.rotation.z = -0.14 + qualify * 0.1;
      });
      const scoreProgress = story ? smooth(0.34, 0.47, p) : smooth(0.5, 0.72, frame.intro);
      index.position.x = -2.1 + 3.82 * scoreProgress;
      selected.surface.material = (story ? p > 0.56 : frame.intro > 0.74)
        ? materials.blue
        : materials.quiet;
      const quiet = story && p > 0.58;
      alternateA.group.position.y = quiet ? -0.14 : 0;
      alternateB.group.position.y = quiet ? -0.14 : 0;
      const pt = priority.getPointAt((frame.time * 0.09) % 1);
      pulse.position.copy(pt);
      pulse.position.y += 0.025;
      pulse.visible = frame.intro >= 0.9;
      pulse.rotation.y = -Math.atan2(
        priority.getTangentAt((frame.time * 0.09) % 1).z,
        priority.getTangentAt((frame.time * 0.09) % 1).x,
      );
      for (let i = 0; i < 3; i++) {
        const v = priority.getPointAt(0.3 + i * 0.22);
        tmp.position.copy(v);
        tmp.position.z += 1.02;
        tmp.position.y += 0.13;
        tmp.scale.set(0.22, story && p > 0.67 + i * 0.035 ? 0.22 : 0.06, 0.22);
        tmp.rotation.set(0, 0, 0);
        tmp.updateMatrix();
        actionTicks.setMatrixAt(i, tmp.matrix);
      }
      actionTicks.instanceMatrix.needsUpdate = true;
      anchor(0, packet.position, -10, story ? -105 : 75);
      anchor(1, new THREE.Vector3(0.6, 1, 1.5), -5, 60);
      anchor(2, end, -20, -95);
      try {
        renderer.render(scene, camera);
        ready(true);
      } catch {
        lost = true;
        ready(false);
      }
      element!.dataset.drawCalls = String(renderer.info.render.calls);
      element!.dataset.triangles = String(renderer.info.render.triangles);
      element!.dataset.dpr = String(dpr);
      element!.dataset.progress = p.toFixed(3);
      element!.dataset.frames = String(++drawCount);
      const cost = performance.now() - started;
      total += cost;
      samples++;
      if (samples >= 120) {
        element!.dataset.cpuMs = (total / samples).toFixed(2);
        if (total / samples > 18) {
          slow++;
          if (dpr > 1) {
            dpr = 1;
            renderer.setPixelRatio(dpr);
            renderer.setSize(width, height, false);
          }
        }
        total = 0;
        samples = 0;
      }
      lastRender = now;
    }
    function resize() {
      const rect = element!.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      if (!width || !height) return;
      renderer.setSize(width, height, false);
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.shadowMap.needsUpdate = true;
      draw(true);
    }
    const unsub = clock.subscribe((next: SceneFrame) => {
      frame = next;
      draw();
    });
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(element);
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) draw(true);
    });
    observer.observe(element);
    const lostContext = (event: Event) => {
      event.preventDefault();
      lost = true;
      ready(false);
    };
    const restoreContext = () => {
      lost = false;
      renderer.shadowMap.needsUpdate = true;
      draw(true);
    };
    renderer.domElement.addEventListener('webglcontextlost', lostContext);
    renderer.domElement.addEventListener('webglcontextrestored', restoreContext);
    resize();
    return () => {
      disposed = true;
      unsub();
      resizeObserver.disconnect();
      observer.disconnect();
      renderer.domElement.removeEventListener('webglcontextlost', lostContext);
      renderer.domElement.removeEventListener('webglcontextrestored', restoreContext);
      ready(false);
      instanced.forEach((m) => m.dispose());
      geometries.forEach((g) => g.dispose());
      Object.values(materials).forEach((m) => m.dispose());
      environment.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [clock]);
  return <div className="spatial-webgl" ref={host} aria-hidden="true" />;
}
