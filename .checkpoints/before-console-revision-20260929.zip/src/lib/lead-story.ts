import { qualify, type LeadInput } from './domain';

// This is an illustrative lifecycle, never a stored workspace record.
export const storyInput: LeadInput = {
  name: 'Alex Morgan',
  company: 'Northline Studio',
  email: 'alex.morgan@example.com',
  service: 'Website redesign',
  budget: '£5,000–£10,000',
  timeline: 'Within 30 days',
};
export const storyLead = {
  ...storyInput,
  ...qualify(storyInput),
  reference: 'G / 001',
  owner: 'Jamie Lee',
};
export const storyStages = [
  'Capture',
  'Qualify',
  'Score',
  'Route',
  'Follow up',
  'Convert',
] as const;
export const storyChapters = [
  {
    title: 'A hello. With potential.',
    description: 'A new enquiry arrives with a name, a project and a possible next chapter.',
    receipt: 'Website enquiry received',
  },
  {
    title: 'The details become direction.',
    description:
      'Company, budget and timing resolve into clear signals. Useful context, ready to act on.',
    receipt: 'Context, budget and timing resolved',
  },
  {
    title: 'Intent, made tangible.',
    description:
      '30 base + 35 budget + 21 timing + 5 company. A score with a reason behind every point.',
    receipt: '91 / 100 · High intent',
  },
  {
    title: 'One lead. The right path.',
    description:
      'Three possible routes. A score of 75 or more takes Alex to Jamie in the priority sales queue.',
    receipt: 'Priority sales → Jamie Lee',
  },
  {
    title: 'Keep the possibility moving.',
    description:
      'Prepare a first response. Schedule the next check. Let the conversation keep its momentum.',
    receipt: 'Simulation · Response prepared · +1 day reminder',
  },
  {
    title: 'An opportunity. With a future.',
    description:
      'The same lead arrives in the pipeline, with its context, owner and next action intact.',
    receipt: 'Illustrative opportunity · Qualified · £7,500',
  },
] as const;
export type SceneFrame = {
  progress: number;
  intro: number;
  time: number;
  story: boolean;
  pointerX: number;
  pointerY: number;
};
export type SceneClock = {
  getSnapshot: () => SceneFrame;
  subscribe: (listener: (frame: SceneFrame) => void) => () => void;
};
export const routeNodes = {
  main: [
    [-18, 0.8, 8],
    [-10, 1.2, 6],
    [-7, 1.8, 1],
    [-3, 1.6, -1],
    [2.6, 0.9, -1],
  ],
  priority: [
    [2.6, 0.9, -1],
    [5, 0.9, -4],
    [4, 1.3, -8],
    [7, 1.3, -13],
  ],
  discovery: [
    [2.6, 0.9, -1],
    [6, 0.7, 0.5],
    [10, 0.7, 1.8],
    [16, 0.7, 1.8],
  ],
  nurture: [
    [2.6, 0.9, -1],
    [4.5, 0.7, 2.7],
    [7, 0.7, 6],
    [14, 0.7, 8],
  ],
} as const;
