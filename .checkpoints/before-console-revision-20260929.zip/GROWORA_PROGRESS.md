# Growora — Progress checkpoint

**Updated: 27 September 2026**  
**Current phase: final creative direction completed; implementation pending.**  
**Next stage: 1 — Foundations and static hero.**

The authoritative direction is [GROWORA_FINAL_DESIGN_PLAN.md](./GROWORA_FINAL_DESIGN_PLAN.md). Read it before editing. This checkpoint prevents an interrupted turn from causing a project restart or another design exploration.

## What happened in this turn

- Read the full supplied final-direction brief and the repository's Next.js agent instructions.
- Inventoried all source components, routing, dependencies, styles, tests, configuration and assets. Reviewed the implementation and its shared local data model.
- Ran the existing site and visually reviewed the entire homepage, including the footer, at **1440 × 900** and **390 × 844**, scrolling through both.
- Reviewed key working app screens at desktop/mobile, including overview, leads/detail, pipeline, automations/editor, forms/builder and analytics; also mobile settings.
- Reviewed desktop product, solutions, integrations and pricing pages. Other supporting pages were inspected in source, not each individually rendered.
- Exercised the existing automation Test flow / Stop simulation. No leads were created, moved, deleted or reset. No settings were changed. An existing local demo record was present; the browser had 21 records after hydration versus 20 source fixtures.
- Chose ONE final direction: **Growora — Directed momentum**. Preserve Fieldwork's paper/ink/cobalt/editorial identity; express energy through an understandable lead route and a stable lead object.
- Wrote the complete A–R implementation blueprint, including five motion signatures, hero geometry/timing/fallback, every homepage section, mobile adaptations, data ownership, product UI, file responsibilities, performance/accessibility and stage gates.
- **No production application source was redesigned. No optional prototype was built. No dependencies were installed. No deployment was performed.** Build/typecheck may regenerate normal `.next` and TypeScript cache artifacts.

## Current implementation

The supplied app is runnable and substantial. It is a Next.js 16.3.6 / React 19.3.0 local portfolio demonstration with working capture, deterministic qualification, lead management, pipeline movement, automation simulation/settings, form builder/preview, analytics, integration simulation, workspace settings and supporting marketing pages.

Important files:

- `src/app/page.tsx`: current homepage composition.
- `src/components/marketing/hero.tsx` and `src/components/three/lead-engine.tsx`: current editorial hero and processor-style routing board.
- `src/components/marketing/sections.tsx`: shared story, pipeline, analytics, solutions, connections, philosophy and pricing sections.
- `src/components/product/*`: reusable working demonstrations and dashboard.
- `src/components/app/*`: product pages and shell.
- `src/components/providers.tsx`, `src/lib/domain.ts`, `src/data/demo.ts`: shared persistence, business rules and fixtures. Preserve their contracts.
- Root CSS import order: `globals.css`, `product-surfaces.css`, `art-direction.css`; app also imports `app.css`, `design.css`.

There is no `public/` photo/model library. Existing assets are procedural DOM/SVG/Three graphics, local fonts, the favicon and generated OG image. No Motion/GSAP/R3F dependency exists. One editorial photo is planned but not yet sourced; its intentional typographic fallback is specified.

The repository directory **does not contain `.git` metadata**. No reliable prior commit/turn history was available, so specific interrupted edits cannot be reconstructed. Do not label deliberate local-demo limitations as abandoned implementation. Before future code edits, establish a recoverable source snapshot or use version control if it has since become available.

## Verification baseline

| Check | Result on 27 September 2026 |
| --- | --- |
| `npm run dev` | Started successfully at `http://localhost:3000`; used for browser review |
| `npm run build` | Passed; Next generated 26 pages |
| `npm run typecheck` | Passed |
| `npm run lint` | Passed |
| `npm run test` | Passed, 5 tests, 0 failures |
| Browser errors/warnings | No entries returned in the final inspected log sample |
| Visual homepage audit | Complete at 1440×900 and 390×844 |
| Production performance measurement | Not performed; plan budgets are targets, not measured claims |
| Full end-to-end mutation regression | Not performed this turn; domain tests/source inspected, automation simulation exercised |
| Accessibility certification | Not performed; current primitives inspected and future checks specified |

The development server was left available for review. Its long-running terminal session was `32035` during this turn. Verify the listening port/process before reusing or starting a server in a later turn; session availability is not guaranteed across interruptions.

Installed Next documentation consulted:

- `node_modules/next/dist/docs/01-app/01-getting-started/05-server-and-client-components.md`
- `node_modules/next/dist/docs/01-app/02-guides/lazy-loading.md`

Read the relevant installed guide again only when a new API/task requires it. `ssr: false` belongs in a Client Component; route params are asynchronous in this application. Follow `AGENTS.md` instead of substituting older conventions.

## Implementation stages

Stage definitions and acceptance gates are in section P of the design plan.

| Stage | Status | Output / remaining work |
| --- | --- | --- |
| 0 — Recovery and direction | **Complete** | Audit, final decisions, blueprint, checkpoint, passing baseline |
| 1 — Foundations and static hero | Not started — **NEXT** | Snapshot, token ownership, shared example/topology, SVG fallback, desktop/mobile composition |
| 2 — Lead Engine motion and 3D | Not started | One purposeful routing scene, synchronized motion, pause/replay, lifecycle/DPR |
| 3 — Six-stage journey | Not started | Persistent specimen, bounded desktop runway, mobile/manual/reduced versions |
| 4 — Real lead handoff | Not started | Immediate insertion, one UUID, active lead reference, focused preview and highlight readiness |
| 5 — Automation execution | Not started | Shared rules, compact showcase, finite causal run, full editor refinements |
| 6 — Pipeline and truthful insight | Not started | Single homepage opportunity, consistent reporting, accurate chart/bar scales |
| 7 — Human context and page cadence | Not started | One photo or defined fallback, section rhythm, solutions/connections/pricing |
| 8 — Final conversion closure | Not started | Cobalt final field, truthful example/actual terminal, once-only motion |
| 9 — Product refinement | Not started | Task hierarchy, data density, mobile views, form summaries, inspector and settings polish |
| 10 — Consolidation and release QA | Not started | CSS/fonts/performance/accessibility/route regression and final visual verification |

## Technical decisions already made

1. Keep current architecture, dependencies, local storage keys, records and scoring outputs. No project restart, backend expansion or package upgrade.
2. The hero remains a full-width masthead and machine composition. Replace the decorative processor with three open qualification gates, a score rail and explicit routes. No floating object beside text.
3. Only the hero uses WebGL, at ≥1024 px. Mobile, reduced motion and failed WebGL use a complete SVG/DOM representation. No second canvas or animation framework.
4. Six-stage story includes Capture, Qualify, Score, Route, Follow up and Convert. It is an illustrative lifecycle and never mutates actual records.
5. The canonical illustrative `G / 001` input is separate from source `sample-1`, whose owner/status differ. It must not be inserted into the provider.
6. A valid submitted lead is saved immediately, exactly once. Motion follows the commit. Homepage continuity references its UUID through a small context; the app uses the existing highlight URL.
7. Automation simulation is finite, tests the actual configured budget condition and never sends data or modifies a lead. High budget is not synonymous with high intent.
8. Marketing becomes focused; full dashboard, automation editor, board and analytics remain in the app. Appropriate tables/kanban are retained.
9. Keep Newsreader + DM Sans, reduce operational type disparity, adopt readable labels. Remove Manrope only after migrating actual uses and testing.
10. Consolidate CSS incrementally in current files; no new blanket override stylesheet and no deletion of unported rules.
11. Use exactly one editorial photograph if a suitable licensed image is acquired. No photo is needed for the hero. The plan includes an intentional non-photo fallback.
12. Only final CTA becomes a large cobalt field. Meaningful object motion supplies energy; calm sections remain still.

## Known issues and incomplete work

These are observations/planned corrections, not changes made in this turn:

- Hero packets are too small/subtle; processor symbolism and static score do not show a causal qualification sequence.
- Repeated heading/frame composition makes the long homepage feel uniform. Dashboard and automation take several mobile screens each.
- Workflow currently has five stages, no separate Score, a short scroll span, remounted examples, and an indefinite manual override.
- Mobile capture title joins words when `<br>` is hidden; diagram and product annotation sizes are too small.
- Provider data initially shows fixtures before hydration restores existing local records. The `ready` flag should be respected in affected displays.
- Lead insertion currently waits for the presentation timer; leaving can cancel it. Reduced-motion CSS does not bypass the JavaScript wait.
- Some fixture scores do not reproduce the current input formula; route/breakdown presentation must not misrepresent recorded samples.
- Analytics reporting windows differ across screens; certain funnel/bar widths are decorative. They need explicit accurate scales/labels.
- Automation repeats CSS highlights indefinitely, and some edited values/configuration labels lose context. Marketing should use a compact finite execution view.
- Autosaved forms/settings/automation offer Save controls that merely change labels. Clarify language while preserving data behavior.
- App headings occupy too much space relative to tiny operational text; mobile tables/boards put important data offscreen.
- CSS has layered duplicate ownership. Font subset and production performance budgets have not yet been measured or optimized.
- No image has been licensed/acquired. This does not block Stages 1–6.
- No blocking build/type/lint/test failures are known. All final-design code stages remain unimplemented.

## Exact next-turn starting instruction

Execute **Stage 1 only as the first implementation unit**. Read the plan's C/D/I/O/P/Q sections and relevant installed Next docs. Preserve a recoverable baseline. Build the static, accessible hero composition and shared routing topology at 1440×900 and 390×844, preserving routes and state. Verify visually before beginning the sophisticated renderer in Stage 2. Do not spend another turn proposing alternate creative directions.

## Checkpoint update protocol

After each implementation unit:

1. Update the date and current/next stage.
2. Mark only work that actually passed its gate as complete; use “in progress” for partial stages.
3. Record concrete changed files/components and important decisions, not a transcript of tool calls.
4. Record commands/browser sizes/cases actually checked, their results and any unverified assumptions.
5. Note any test-created local records, storage/schema changes, active processes or remaining asset needs.
6. Add known regressions or blockers with reproduction steps and the next safe action.
7. Keep the authoritative design decisions in `GROWORA_FINAL_DESIGN_PLAN.md`; update that document if implementation exposes a real constraint, explaining the narrow adjustment. Do not silently redesign.

If interrupted mid-stage, the next turn should continue the incomplete unit from this checkpoint rather than repeating recovery or rewriting successful components.

## Implementation checkpoint — stage 1 (27 September 2026)

Static hero implemented and visually inspected at **1440×900** and **390×844**. Full ultramarine field, large offset Newsreader masthead, paper qualification gates, one signal-orange chamfered ticket, explicit 91 score / Jamie route, and an edge-to-edge exit rail. Mobile uses a separately composed top-down SVG. Both first viewports contain CTA, score and chosen route without clipping. Replaced the old hero's primary CSS block in the existing art-direction layer; no added global stylesheet or dependency.

Changed: `src/components/marketing/hero.tsx`, `src/components/visual/routing-diagram.tsx`, `src/lib/lead-story.ts`, `src/app/art-direction.css`. Baseline source snapshot: `.checkpoints/before-directed-momentum-20260927.zip`. Shared example derives 91 through `qualify`; never inserted into storage.

Current unit: **stage 2 in progress** — synchronized finite hero clock and matching single Three renderer. Stage 1 automated checks will run with integrated hero. No data writes/test records. Dev server: port 3000, exec session 71024. Next: inspect animated hero in desktop/mobile, then integrate the six-stage journey. Remaining original stages 4–10 unchanged.

## 28 September 2026 — Milestone A: replacement spatial hero

The previous cobalt/serif/arch direction was **rejected by the user**. It is superseded, not a foundation to polish. Scope for this run is ONLY the new hero and its continuous six-stage scroll world. Do not start handoff, pricing, app or footer work.

Replacement implemented in `marketing/hero.tsx`, `three/lead-engine.tsx`, `visual/routing-diagram.tsx`, `visual/lead-specimen.tsx`, `lib/lead-story.ts`, and the existing `art-direction.css` hero block. Contemporary DM Sans, a neutral spatial field, solid indigo branching tracks, ceramic/metal layered packet, thin qualification vanes and physical score ruler. Real procedural Three lighting and static contact shadows; no downloaded assets/frameworks. The packet and routes are large and spatially connected to the HTML labels. First pass was revised after browser inspection to deepen the selected branch, increase packet/track scale and correct a headline/label collision.

Hero visually checked at **1440×900** (actual canvas loaded, 39–40 draw calls, approximately 10,062 triangles) and **390×844** (separate SVG/DOM composition). CTA is immediately usable. Desktop has a 2.9s opening, pause/replay and restrained idle activity. Mobile runs the shorter lightweight representation, no WebGL. Initial measured renderer CPU sample was ~1.23ms in this desktop dev browser; this is not a GPU/Lighthouse/performance certification. DPR capped at 1.25 and degrades to 1; rendering stops offscreen/hidden/paused. Static shadow map, one context and no network graphics.

Typecheck passed; lint passed except one unused placeholder argument, subsequently removed. Browser review exposed deprecated Three PCFSoftShadowMap, changed to supported PCFShadowMap. Build and final regression still pending. Snapshot of pre-revision source: `.checkpoints/before-spatial-revision-20260928.zip`.

**Next: Milestone B** — enable bounded scroll progress on the same mounted renderer, remove the obsolete separate homepage Workflow, inspect all six states and return-to-document behavior, then test production build and update this checkpoint. Existing product/localStorage untouched.
