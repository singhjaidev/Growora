import test from 'node:test';
import assert from 'node:assert/strict';
import { qualify, createLead, metrics, type LeadInput } from '../src/lib/domain.ts';
const input: LeadInput = {
  name: 'Test Person',
  company: 'Sample Studio',
  email: 'test@example.com',
  service: 'Website redesign',
  budget: '£5,000–£10,000',
  timeline: 'Within 30 days',
};
test('high-intent lead receives the documented score and priority route', () => {
  assert.deepEqual(qualify(input), {
    value: 7500,
    score: 91,
    priority: 'High',
    route: 'Priority sales queue',
    action: 'Contact within 10 minutes',
  });
});
test('an exploratory low-budget lead is nurtured instead of sent to priority sales', () => {
  const result = qualify({ ...input, budget: 'Under £2,000', timeline: 'Just exploring' });
  assert.equal(result.score, 47);
  assert.equal(result.priority, 'Nurture');
  assert.equal(result.route, 'Nurture sequence');
});
test('mid-range enquiry receives the discovery route', () => {
  const result = qualify({ ...input, budget: '£2,000–£5,000', timeline: '1–3 months' });
  assert.equal(result.score, 69);
  assert.equal(result.priority, 'Medium');
});
test('lead creation preserves inputs and produces unique identities', () => {
  const first = createLead(input);
  const second = createLead(input);
  assert.notEqual(first.id, second.id);
  assert.equal(first.name, input.name);
  assert.equal(first.email, input.email);
  assert.equal(first.status, 'Qualified');
  assert.equal(first.owner, 'Jamie Lee');
  assert.equal(first.source, 'Website demo');
});
test('workspace metrics respond to pipeline changes and handle an empty workspace', () => {
  const a = createLead(input);
  const b = { ...createLead(input), status: 'Won' as const };
  assert.deepEqual(metrics([a, b]), { count: 2, qualified: 2, value: 7500, conversion: '50.0' });
  assert.deepEqual(metrics([]), { count: 0, qualified: 0, value: 0, conversion: '0.0' });
});
