'use client';
import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import { ArrowDown, ArrowUpRight, Check, Play } from 'lucide-react';
import { ButtonLink, Mark } from '@/components/ui';
const Engine = dynamic(() => import('@/components/three/lead-engine'), { ssr: false });

export function Hero() {
  const [show3d, setShow3d] = useState(false);
  useEffect(() => {
    const media = matchMedia('(min-width: 700px) and (prefers-reduced-motion: no-preference)');
    const update = () => setShow3d(media.matches);
    update();
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);
  return (
    <section className="hero editorial-hero">
      <div className="container hero-inner">
        <div className="hero-edition">
          <span>The lead conversion system</span>
          <span>Interest in. Opportunity out.</span>
          <span>G / 001</span>
        </div>
        <div className="hero-copy">
          <h1>
            <span>Good leads deserve</span>
            <em>a clear next step.</em>
          </h1>
          <div className="hero-introduction">
            <p>
              Turn website visitors into qualified opportunities. Growora captures the context,
              finds the intent, and keeps the conversation moving.
            </p>
            <div className="hero-buttons">
              <ButtonLink href="/product">Explore the platform</ButtonLink>
              <a className="watch-button" href="#workflow">
                <Play size={12} />
                Watch it work
              </a>
            </div>
            <span className="hero-note">For service businesses & teams with places to grow.</span>
          </div>
        </div>
        <div className="engine-stage">
          <div className="engine-topline">
            <span>
              <b>01</b> Incoming interest
            </span>
            <span>
              <b>02</b> The Growora engine
            </span>
            <span>
              <b>03</b> A clear next step
            </span>
          </div>
          <div
            className="engine-fallback"
            aria-label="Visitors are captured, qualified and routed to a next step"
          >
            <div className="fallback-inputs">
              <span>Website enquiry</span>
              <span>Project request</span>
              <span>First conversation</span>
            </div>
            <div className="fallback-path" />
            <div className="fallback-core">
              <Mark />
            </div>
            <div className="fallback-path" />
            <div className="fallback-outputs">
              <span>
                Qualified <Check size={12} />
              </span>
              <span>
                Follow-up <ArrowUpRight size={12} />
              </span>
              <span>
                Booked <Check size={12} />
              </span>
            </div>
          </div>
          {show3d && <Engine />}
          <div className="engine-input-register">
            <p>Every signal has potential.</p>
            {[
              ['01', 'Website enquiry'],
              ['02', 'Project request'],
              ['03', 'First conversation'],
            ].map(([n, t]) => (
              <span key={n}>
                <small>{n}</small>
                {t}
                <i />
              </span>
            ))}
          </div>
          <div className="engine-output-register">
            <span className="routing-ticket-label">ROUTING RECORD / EXAMPLE</span>
            <div>
              <strong>91</strong>
              <span>
                Lead score<small>High intent identified</small>
              </span>
            </div>
            <div className="ticket-ruler">
              <i />
            </div>
            <p>
              <span>Next step</span>
              <strong>
                Priority sales queue <ArrowUpRight size={13} />
              </strong>
            </p>
          </div>
          <div className="engine-spec">
            <span>Capture</span>
            <span>Qualify</span>
            <span>Score</span>
            <span>Route</span>
            <span>Convert</span>
          </div>
        </div>
        <div className="hero-baseline">
          <span>Less administration. More possibility.</span>
          <a href="#workflow">
            Follow the process <ArrowDown size={13} />
          </a>
          <span>
            <i className="live-dot" /> Interactive product demonstration
          </span>
        </div>
      </div>
    </section>
  );
}
