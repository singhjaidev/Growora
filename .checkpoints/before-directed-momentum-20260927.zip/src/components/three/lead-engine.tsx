'use client';
import { useEffect, useRef } from 'react';
import * as THREE from 'three';
/** A physical routing board. Curves and packets share the same paths. */
export default function LeadEngine() {
  const host = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const element = host.current;
    if (!element) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        alpha: true,
        antialias: true,
        powerPreference: 'low-power',
      });
    } catch {
      return;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.7));
    renderer.setClearColor(0x000000, 0);
    element.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    const camera = new THREE.OrthographicCamera(-10, 10, 3.6, -3.6, 0.1, 100);
    camera.position.set(1.8, 8, 10);
    camera.lookAt(0, 0, 0);
    const group = new THREE.Group();
    scene.add(group);
    scene.add(new THREE.AmbientLight(0xffffff, 2.2));
    const key = new THREE.DirectionalLight(0xfff7e5, 3.5);
    key.position.set(2, 9, 4);
    scene.add(key);
    const fill = new THREE.PointLight(0xffffff, 8, 12);
    fill.position.set(-1, 3, 1);
    scene.add(fill);
    const dark = new THREE.MeshStandardMaterial({
      color: 0xd4d5cc,
      metalness: 0.35,
      roughness: 0.35,
    });
    const edge = new THREE.MeshStandardMaterial({
      color: 0x8799aa,
      metalness: 0.35,
      roughness: 0.28,
    });
    const lime = new THREE.MeshStandardMaterial({
      color: 0x2948a7,
      emissive: 0x000000,
      emissiveIntensity: 0,
      metalness: 0.3,
      roughness: 0.4,
    });
    function box(
      w: number,
      h: number,
      d: number,
      x: number,
      y: number,
      z: number,
      mat: THREE.Material,
    ) {
      const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat);
      mesh.position.set(x, y, z);
      group.add(mesh);
      return mesh;
    }
    box(3.05, 0.18, 3.05, 0, -0.34, 0, dark);
    box(2.75, 0.13, 2.75, 0, -0.16, 0, edge);
    box(2.55, 0.27, 2.55, 0, 0.05, 0, dark);
    box(2.22, 0.06, 2.22, 0, 0.22, 0, edge);
    box(2.05, 0.12, 2.05, 0, 0.29, 0, dark);
    // Precision traces across a layered processor, with a custom G routing mark.
    const mark = new THREE.BufferGeometry().setFromPoints(
      [
        [-0.45, 0, -0.65],
        [0.4, 0, -0.65],
        [0.65, 0, -0.4],
        [0.65, 0, 0.4],
        [0.4, 0, 0.65],
        [-0.4, 0, 0.65],
        [-0.65, 0, 0.4],
        [-0.65, 0, -0.3],
        [0, 0, -0.3],
        [0, 0, 0.15],
      ].map((p) => new THREE.Vector3(p[0], 0.365, p[2])),
    );
    const logo = new THREE.Line(mark, new THREE.LineBasicMaterial({ color: 0x263e88 }));
    group.add(logo);
    for (let i = 0; i < 9; i++) {
      const p = -1.02 + i * 0.255;
      box(0.07, 0.04, 0.27, p, 0.06, 1.48, edge);
      box(0.07, 0.04, 0.27, p, 0.06, -1.48, edge);
      box(0.27, 0.04, 0.07, 1.48, 0.06, p, edge);
      box(0.27, 0.04, 0.07, -1.48, 0.06, p, edge);
    }
    const paths: THREE.CatmullRomCurve3[] = [];
    for (let i = 0; i < 7; i++) {
      const z = (i - 3) * 0.68;
      const path = new THREE.CatmullRomCurve3([
        new THREE.Vector3(-5.7, 0, z * 1.3),
        new THREE.Vector3(-3.7, 0, z * 1.3),
        new THREE.Vector3(-2.4, 0, z * 0.52),
        new THREE.Vector3(-1.5, 0, z * 0.52),
      ]);
      paths.push(path);
    }
    for (let i = 0; i < 4; i++) {
      const z = (i - 1.5) * 1.15;
      const path = new THREE.CatmullRomCurve3([
        new THREE.Vector3(1.5, 0.02, z * 0.5),
        new THREE.Vector3(2.5, 0.02, z * 0.5),
        new THREE.Vector3(3.4, 0.02, z),
        new THREE.Vector3(4.8, 0.02, z),
      ]);
      paths.push(path);
      box(0.72, 0.12, 0.72, 4.95, 0.03, z, dark);
      box(0.38, 0.025, 0.38, 4.95, 0.105, z, i === 3 ? edge : lime);
    }
    paths.forEach((path, i) => {
      const line = new THREE.Line(
        new THREE.BufferGeometry().setFromPoints(path.getPoints(70)),
        new THREE.LineBasicMaterial({
          color: i < 7 ? 0x899389 : 0x36549b,
          transparent: true,
          opacity: i < 7 ? 0.55 : 0.85,
        }),
      );
      group.add(line);
    });
    const packets = paths.map((path, i) => {
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(i < 7 ? 0.037 : 0.052, 6, 6), lime);
      group.add(mesh);
      return { mesh, path, offset: i * 0.13 };
    });
    const grid = new THREE.GridHelper(18, 36, 0xc3c7bb, 0xd4d7cc);
    grid.position.y = -0.5;
    group.add(grid);
    let visible = true;
    let frame = 0;
    let raf = 0;
    let pointerX = 0;
    let pointerY = 0;
    let contextLost = false;
    const loseContext = (event: Event) => {
      event.preventDefault();
      contextLost = true;
      cancelAnimationFrame(raf);
      raf = 0;
      element.dataset.loaded = 'false';
    };
    const restoreContext = () => {
      contextLost = false;
      element.dataset.loaded = 'true';
      if (!raf) animate();
    };
    renderer.domElement.addEventListener('webglcontextlost', loseContext);
    renderer.domElement.addEventListener('webglcontextrestored', restoreContext);
    const onPointer = (e: PointerEvent) => {
      const r = element.getBoundingClientRect();
      pointerX = ((e.clientX - r.left) / r.width - 0.5) * 0.12;
      pointerY = ((e.clientY - r.top) / r.height - 0.5) * 0.06;
    };
    element.addEventListener('pointermove', onPointer);
    const resize = () => {
      const { width, height } = element.getBoundingClientRect();
      renderer.setSize(width, height);
      camera.left = -(width / height) * 3.6;
      camera.right = (width / height) * 3.6;
      camera.updateProjectionMatrix();
    };
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(element);
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible && !raf) animate();
    });
    observer.observe(element);
    const onVisibility = () => {
      if (!document.hidden && visible && !raf) animate();
    };
    document.addEventListener('visibilitychange', onVisibility);
    function animate() {
      raf = 0;
      if (!visible || document.hidden || contextLost) return;
      frame += 0.005;
      group.rotation.y += (pointerX - group.rotation.y) * 0.035;
      group.rotation.x += (pointerY - group.rotation.x) * 0.035;
      packets.forEach(({ mesh, path, offset }) =>
        mesh.position.copy(path.getPoint((frame * 0.35 + offset) % 1)),
      );
      renderer.render(scene, camera);
      raf = requestAnimationFrame(animate);
    }
    resize();
    animate();
    element.dataset.loaded = 'true';
    return () => {
      cancelAnimationFrame(raf);
      observer.disconnect();
      resizeObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibility);
      element.removeEventListener('pointermove', onPointer);
      renderer.domElement.removeEventListener('webglcontextlost', loseContext);
      renderer.domElement.removeEventListener('webglcontextrestored', restoreContext);
      scene.traverse((object) => {
        if (object instanceof THREE.Mesh || object instanceof THREE.Line) {
          object.geometry.dispose();
          const materials = Array.isArray(object.material) ? object.material : [object.material];
          materials.forEach((m: THREE.Material) => m.dispose());
        }
      });
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);
  return <div className="webgl-engine" ref={host} aria-hidden="true" />;
}
