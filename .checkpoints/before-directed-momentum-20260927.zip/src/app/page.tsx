import { MarketingShell, FinalCTA } from '@/components/marketing/shell';
import { Hero } from '@/components/marketing/hero';
import {
  Problem,
  Workflow,
  PipelineSection,
  AnalyticsSection,
  SolutionsSelector,
  IntegrationUniverse,
  Pricing,
  Philosophy,
} from '@/components/marketing/sections';
import { DashboardPreview } from '@/components/product/dashboard';
import { LeadCapture } from '@/components/product/lead-capture';
import { AutomationSection } from '@/components/product/automation';
export const metadata = { alternates: { canonical: '/' } };
export default function Home() {
  return (
    <MarketingShell>
      <Hero />
      <Problem />
      <Workflow />
      <DashboardPreview />
      <LeadCapture />
      <AutomationSection />
      <PipelineSection />
      <AnalyticsSection />
      <SolutionsSelector />
      <IntegrationUniverse />
      <Philosophy />
      <Pricing />
      <FinalCTA />
    </MarketingShell>
  );
}
