'use client';
import { useState } from 'react';
import Link from 'next/link';
import { ArrowDown, ArrowUpRight } from 'lucide-react';
import { useLeads } from '@/components/providers';
import { money, metrics, stages } from '@/lib/domain';
import { VolumeChart } from '@/components/product/dashboard';
import { AppHeading } from './shell';
export function AnalyticsPage() {
  const { leads } = useLeads();
  const [range, setRange] = useState('30');
  const filtered = leads.filter(
    (l) => range === '30' || Date.parse(l.created) >= Date.UTC(2026, 8, 20),
  );
  const m = metrics(filtered);
  const won = filtered.filter((l) => l.status === 'Won').length;
  const proposal = filtered.filter((l) => ['Proposal', 'Won'].includes(l.status)).length;
  const qualified = filtered.filter((l) => l.status !== 'New').length;
  const funnel = [
    ['Visitors', range === '30' ? 800 : 360],
    ['Captured', filtered.length],
    ['Qualified', qualified],
    ['Proposal', proposal],
    ['Won', won],
  ] as [string, number][];
  return (
    <>
      <AppHeading
        eyebrow="UNDERSTAND THE SIGNAL"
        title="A clearer picture of growth."
        description="Follow the journey, find the friction, and see where opportunities begin."
      >
        <label className="analytics-range">
          Reporting period
          <select value={range} onChange={(e) => setRange(e.target.value)}>
            <option value="30">September 2026 · 30 days</option>
            <option value="7">20–26 Sep 2026 · 7 days</option>
          </select>
        </label>
      </AppHeading>
      <div className="analytics-kpis">
        {[
          ['Captured', m.count],
          ['High-intent', m.qualified],
          ['Open pipeline', money(m.value)],
          ['Won rate', `${m.conversion}%`],
        ].map(([label, value]) => (
          <div key={label}>
            <span>
              {label}
              <ArrowUpRight size={14} />
            </span>
            <strong>{value}</strong>
            <small>Selected reporting period</small>
          </div>
        ))}
      </div>
      <div className="analytics-main-grid">
        <section className="chart-panel">
          <div className="panel-heading">
            <h4>Lead growth over time</h4>
            <span>
              <i className="live-dot" /> Captured leads
            </span>
          </div>
          <VolumeChart range={range} large records={filtered} />
        </section>
        <section className="funnel-panel">
          <div className="panel-heading">
            <h4>The conversion journey</h4>
            <span>DEMO FUNNEL</span>
          </div>
          <div className="funnel">
            {funnel.map(([label, count], i) => (
              <div key={label}>
                <span>
                  {label}
                  <strong>{count}</strong>
                </span>
                <div style={{ width: `${100 - i * 16}%`, opacity: 0.35 + i * 0.15 }} />
                {i < 4 && <ArrowDown size={12} />}
              </div>
            ))}
          </div>
          <p className="micro">Visitors are illustrative. Lead stages reflect your workspace.</p>
        </section>
      </div>
      <div className="analytics-secondary-grid">
        <section className="source-performance">
          <div className="panel-heading">
            <h4>Where opportunity begins</h4>
            <span>Source performance</span>
          </div>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Source</th>
                  <th>Leads</th>
                  <th>High intent</th>
                  <th>Won</th>
                  <th>Value</th>
                </tr>
              </thead>
              <tbody>
                {Array.from(new Set(filtered.map((l) => l.source))).map((source) => {
                  const rows = filtered.filter((l) => l.source === source);
                  return (
                    <tr key={source}>
                      <td>
                        <i className="live-dot" />
                        {source}
                      </td>
                      <td>{rows.length}</td>
                      <td>{rows.filter((l) => l.score >= 75).length}</td>
                      <td>{rows.filter((l) => l.status === 'Won').length}</td>
                      <td>{money(rows.reduce((a, l) => a + l.value, 0))}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>
        <section className="stage-value">
          <div className="panel-heading">
            <h4>Value by stage</h4>
            <span>GBP</span>
          </div>
          {stages.map((stage, i) => {
            const value = filtered
              .filter((l) => l.status === stage)
              .reduce((a, l) => a + l.value, 0);
            return (
              <div className="value-bar" key={stage}>
                <div>
                  <span>{stage}</span>
                  <strong>{money(value)}</strong>
                </div>
                <div>
                  <i
                    style={{
                      width: `${Math.min(
                        100,
                        (value /
                          Math.max(
                            1,
                            filtered.reduce((a, l) => a + l.value, 0),
                          )) *
                          300,
                      )}%`,
                      opacity: 0.4 + i * 0.15,
                    }}
                  />
                </div>
              </div>
            );
          })}
        </section>
      </div>
      <div className="analytics-insight">
        <span className="settings-icon">
          <ArrowUpRight size={24} />
        </span>
        <div>
          <h3>Turn the numbers into a next step.</h3>
          <p>
            {m.qualified} high-intent leads in this view. Open the lead directory to see who needs a
            conversation.
          </p>
        </div>
        <Link className="button secondary small" href="/app/leads">
          Review opportunities <ArrowUpRight size={14} />
        </Link>
      </div>
    </>
  );
}
