'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Menu, X, ArrowUpRight } from 'lucide-react';
import { Logo, ButtonLink, Mark } from '@/components/ui';
const links = [
  ['Product', '/product'],
  ['Solutions', '/solutions'],
  ['Integrations', '/integrations'],
  ['Pricing', '/pricing'],
];
export function Header() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 24);
    fn();
    window.addEventListener('scroll', fn, { passive: true });
    return () => window.removeEventListener('scroll', fn);
  }, []);
  useEffect(() => {
    setOpen(false);
  }, [pathname]);
  useEffect(() => {
    if (!open) return;
    const close = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', close);
    return () => window.removeEventListener('keydown', close);
  }, [open]);
  return (
    <header className={`site-header ${scrolled ? 'scrolled' : ''}`}>
      <div className="container nav-inner">
        <Logo />
        <nav
          aria-label="Main navigation"
          className={open ? 'nav-links open' : 'nav-links'}
          id="main-navigation"
        >
          {links.map(([label, href]) => (
            <Link key={href} href={href} aria-current={pathname === href ? 'page' : undefined}>
              {label}
            </Link>
          ))}
          <Link className="mobile-signin" href="/app">
            Sign in to demo <ArrowUpRight size={16} />
          </Link>
        </nav>
        <div className="nav-actions">
          <Link href="/app" className="signin">
            Sign in <ArrowUpRight size={13} />
          </Link>
          <ButtonLink href="/app" secondary>
            Explore demo
          </ButtonLink>
          <button
            aria-label={open ? 'Close menu' : 'Open menu'}
            aria-expanded={open}
            aria-controls="main-navigation"
            className="menu-button icon-button"
            onClick={() => setOpen(!open)}
          >
            {open ? <X /> : <Menu />}
          </button>
        </div>
      </div>
    </header>
  );
}
export function Footer() {
  return (
    <footer className="footer container">
      <div className="footer-top">
        <div>
          <Logo />
          <p>
            A clear path from
            <br />
            interest to opportunity.
          </p>
          <span className="micro">An interactive portfolio product.</span>
        </div>
        {[
          [
            'Product',
            ['Platform', '/product'],
            ['Automations', '/product#automation'],
            ['Lead management', '/app/leads'],
            ['Analytics', '/app/analytics'],
          ],
          [
            'Explore',
            ['Solutions', '/solutions'],
            ['Integrations', '/integrations'],
            ['Pricing', '/pricing'],
            ['Interactive demo', '/demo'],
          ],
          [
            'Resources',
            ['Our approach', '/about'],
            ['Documentation', '/docs'],
            ['Guides', '/guides'],
            ['Contact', '/contact'],
          ],
          ['Legal', ['Privacy', '/privacy'], ['Terms', '/terms']],
        ].map(([title, ...items]) => (
          <div key={String(title)}>
            <p className="kicker">{title as string}</p>
            {(items as string[][]).map(([label, url]) => (
              <Link href={url} key={url}>
                {label}
              </Link>
            ))}
          </div>
        ))}
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} Growora. Built with intent.</span>
        <span>
          <i className="live-dot" /> Every lead deserves a next step.
        </span>
        <a href="#main" aria-label="Back to top">
          <Mark />
        </a>
      </div>
    </footer>
  );
}
export function FinalCTA() {
  return (
    <section className="final-cta container">
      <div className="cta-line" />
      <p className="kicker">LESS FRICTION. MORE FORWARD.</p>
      <h2>
        Stop collecting leads.
        <br />
        <span>Start converting them.</span>
      </h2>
      <ButtonLink href="/demo">See Growora in action</ButtonLink>
      <p className="micro">Explore the product. No account needed.</p>
    </section>
  );
}
export function MarketingShell({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Header />
      <main id="main">{children}</main>
      <Footer />
    </>
  );
}
