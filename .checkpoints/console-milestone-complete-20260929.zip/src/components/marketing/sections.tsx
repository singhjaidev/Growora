'use client';
import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  CheckCheck,
  Clock3,
  GitBranch,
  Mail,
  MousePointer2,
  MoveRight,
  Send,
  Sparkles,
  Target,
} from 'lucide-react';
import { ButtonLink, Mark, SectionTitle, Status, tabKeyboard, ScoreMeter } from '@/components/ui';
import { useLeads } from '@/components/providers';
import { money, stages } from '@/lib/domain';
import { VolumeChart } from '@/components/product/dashboard';
import { integrations } from '@/data/demo';
export function Problem() {
  const [organized, setOrganized] = useState(false);
  return (
    <section className="section container problem-section">
      <div className="problem-text">
        <p className="kicker">01 / CLOSE THE GAP</p>
        <h2>
          Your best leads
          <br />
          shouldn’t disappear
          <br />
          <span className="muted">into an inbox.</span>
        </h2>
        <p>
          Interest moves fast. Inboxes don’t.
          <br />
          Give good opportunities a better place to land.
        </p>
        <button className="text-button" onClick={() => setOrganized(!organized)}>
          {organized ? 'See the inbox problem' : 'Bring some order'}
          <ArrowRight size={16} />
        </button>
      </div>
      <div className={`chaos-system ${organized ? 'organized' : ''}`}>
        <div className="chaos-label">
          <span>WITHOUT A SYSTEM</span>
          <span>WITH GROWORA</span>
        </div>
        <div className="lost-signals">
          {[
            ['New enquiry', '2 hours ago'],
            ['Re: Project proposal', 'Follow-up missed'],
            ['Website contact', 'Unassigned'],
          ].map(([title, sub], i) => (
            <div className={`lost-message message-${i}`} key={title}>
              <Mail size={16} />
              <div>
                <strong>{title}</strong>
                <span>{sub}</span>
              </div>
              <i />
            </div>
          ))}
        </div>
        <div className="order-track">
          <i />
          <div className="order-mark">
            <Mark />
          </div>
          <i />
        </div>
        <div className="ordered-signal">
          <span className="square-check">
            <Check size={20} />
          </span>
          <div>
            <small>NOTHING LOST. NEXT STEP CLEAR.</small>
            <strong>
              {organized ? '3 leads. 3 clear next steps.' : 'Qualified. Assigned. Moving.'}
            </strong>
            <span>
              {organized
                ? 'Your workflow has brought the signals together.'
                : 'The right lead, with the right person.'}
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
const workflowStages = [
  {
    title: 'Capture',
    sub: 'Make the first hello count.',
    description:
      'A considered form collects the context your team needs, right where interest begins.',
    icon: MousePointer2,
  },
  {
    title: 'Qualify',
    sub: 'Find the intent in the details.',
    description: 'Project fit, budget and timing become a clear qualification signal.',
    icon: Target,
  },
  {
    title: 'Route',
    sub: 'The right person. Right away.',
    description: 'Send high-intent enquiries to sales and give early interest room to grow.',
    icon: GitBranch,
  },
  {
    title: 'Follow up',
    sub: 'Keep the conversation moving.',
    description: 'A timely response and a useful reminder keep good leads from going quiet.',
    icon: Send,
  },
  {
    title: 'Convert',
    sub: 'Make progress visible.',
    description: 'Move from first interest to a clear proposal, and from a proposal to a win.',
    icon: CheckCheck,
  },
];
export function Workflow() {
  const [active, setActive] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const manual = useRef(false);
  useEffect(() => {
    const onScroll = () => {
      if (manual.current || !ref.current || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const r = ref.current.getBoundingClientRect();
      if (r.top < innerHeight * 0.75 && r.bottom > 0) {
        const progress = Math.max(
          0,
          Math.min(0.99, (innerHeight * 0.75 - r.top) / (r.height + innerHeight * 0.3)),
        );
        setActive(Math.min(4, Math.floor(progress * 5)));
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);
  const current = workflowStages[active];
  return (
    <section id="workflow" className="section container workflow-section" ref={ref}>
      <SectionTitle
        number="02"
        kicker="ONE CONNECTED JOURNEY"
        title="From a first hello. To a real opportunity."
        description="Five considered steps. One continuous flow. Follow the signal through Growora."
      />
      <div
        className="workflow-rail"
        role="tablist"
        aria-label="Lead journey"
        onKeyDown={tabKeyboard}
      >
        {workflowStages.map((s, i) => (
          <button
            role="tab"
            aria-selected={active === i}
            tabIndex={active === i ? 0 : -1}
            aria-controls="workflow-panel"
            id={`workflow-tab-${i}`}
            key={s.title}
            onClick={() => {
              manual.current = true;
              setActive(i);
            }}
          >
            <span className={`workflow-node ${active === i ? 'active' : ''}`}>
              <s.icon size={19} />
            </span>
            <span>
              <small>0{i + 1}</small>
              {s.title}
            </span>
            {i < 4 && <i />}
          </button>
        ))}
      </div>
      <div
        className="workflow-display"
        role="tabpanel"
        id="workflow-panel"
        aria-labelledby={`workflow-tab-${active}`}
      >
        <div className="workflow-context">
          <span className="large-number">0{active + 1}</span>
          <div>
            <p className="kicker">{current.title.toUpperCase()}</p>
            <h3>{current.sub}</h3>
            <p>{current.description}</p>
            <Link href="/product">
              Explore {current.title.toLowerCase()} <ArrowUpRight size={14} />
            </Link>
          </div>
        </div>
        <div className="workflow-example" key={active}>
          <div className="example-top">
            <span className="avatar">AM</span>
            <span>
              Alex Morgan<small>Northline Studio · Sample lead</small>
            </span>
            <Status>
              {
                ['New enquiry', 'Qualified', 'Assigned', 'In conversation', 'Opportunity won'][
                  active
                ]
              }
            </Status>
          </div>
          {active === 0 ? (
            <div className="capture-example">
              <div>
                <span>Service</span>
                <strong>Website redesign</strong>
              </div>
              <div>
                <span>Budget</span>
                <strong>£5,000–£10,000</strong>
              </div>
              <div>
                <span>Timeline</span>
                <strong>Within 30 days</strong>
              </div>
              <div className="example-success">
                <Check size={15} /> The details that make a difference.
              </div>
            </div>
          ) : active === 1 ? (
            <div className="qualification-example">
              <ScoreMeter score={91} />
              <div>
                {['Strong project fit', 'Budget confirmed', 'Ready within 30 days'].map((t) => (
                  <p key={t}>
                    <Check size={15} />
                    {t}
                  </p>
                ))}
              </div>
            </div>
          ) : active === 2 ? (
            <div className="routing-example">
              <span>
                <Target />
                High intent
              </span>
              <MoveRight />
              <span className="route-person">
                <span className="avatar">JL</span>Jamie Lee<small>Priority sales queue</small>
              </span>
            </div>
          ) : active === 3 ? (
            <div className="timeline-example">
              {[
                ['Just now', 'Personal response prepared'],
                ['Tomorrow', 'Check for a reply'],
                ['Day 3', 'Helpful follow-up reminder'],
              ].map(([time, label]) => (
                <div key={time}>
                  <span />
                  <small>{time}</small>
                  <strong>{label}</strong>
                </div>
              ))}
            </div>
          ) : (
            <div className="won-example">
              <CheckCheck size={32} />
              <div>
                <p>From enquiry to opportunity.</p>
                <strong>
                  £7,500<span> WON</span>
                </strong>
              </div>
              <span className="status">Next step: onboarding</span>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
export function PipelineSection() {
  const { leads, updateLead } = useLeads();
  const lead = leads[0];
  return (
    <section className="section container pipeline-section">
      <SectionTitle
        number="06"
        kicker="PROGRESS YOU CAN SEE"
        title="A pipeline with a pulse."
        description="Every conversation has a place. Every opportunity has a next move."
      />
      <div className="mini-kanban">
        {stages.map((stage, i) => (
          <div key={stage}>
            <div className="kanban-column-title">
              <i style={{ opacity: 0.4 + i * 0.15 }} />
              {stage}
              <small>{leads.filter((l) => l.status === stage).length}</small>
            </div>
            {leads
              .filter((l) => l.status === stage)
              .slice(0, 2)
              .map((l) => (
                <div className="kanban-card" key={l.id}>
                  <span className="card-company">
                    {l.company}
                    <span className="score-chip">{l.score}</span>
                  </span>
                  <strong>{l.name}</strong>
                  <span className="card-service">{l.service}</span>
                  <div>
                    <b>{money(l.value)}</b>
                    <span className="avatar small-avatar">
                      {l.owner
                        .split(' ')
                        .map((s) => s[0])
                        .join('')}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        ))}
      </div>
      <div className="under-window">
        <span>Sample opportunities, connected to your demo workspace.</span>
        {lead && (
          <button
            className="text-button"
            onClick={() =>
              updateLead(lead.id, { status: stages[(stages.indexOf(lead.status) + 1) % 5] })
            }
          >
            Move {lead.name.split(' ')[0]} to {stages[(stages.indexOf(lead.status) + 1) % 5]}{' '}
            <ArrowRight size={15} />
          </button>
        )}
      </div>
    </section>
  );
}
export function AnalyticsSection() {
  return (
    <section className="section container analytics-marketing">
      <div>
        <p className="kicker">07 / SIGNAL, NOT NOISE</p>
        <h2>
          Know what’s working.
          <br />
          <span className="muted">Know what’s next.</span>
        </h2>
        <p>
          See where opportunities come from, where they slow down, and where your process can
          improve.
        </p>
        <ButtonLink href="/app/analytics" secondary>
          Find your growth signals
        </ButtonLink>
      </div>
      <div className="analytics-visual">
        <div className="panel-heading">
          <h4>Momentum over time</h4>
          <span className="status">SAMPLE TREND</span>
        </div>
        <VolumeChart />
        <div className="analytic-bottom">
          <span>
            <Clock3 size={17} /> Less waiting
          </span>
          <span>
            <Target size={17} /> Better qualification
          </span>
          <span>
            <ArrowUpRight size={17} /> Clearer outcomes
          </span>
        </div>
      </div>
    </section>
  );
}
const industries = [
  {
    name: 'Agencies',
    problem: 'Great projects get buried under enquiries that aren’t a fit.',
    source: 'New project enquiry',
    qualify: 'Project type · Budget · Urgency',
    action: 'Priority consultation',
    detail:
      'Spot the projects your team is built for. Route qualified prospects to discovery and guide early-stage enquiries toward useful resources.',
  },
  {
    name: 'Real estate',
    problem: 'The right enquiry needs the right local agent.',
    source: 'Property website enquiry',
    qualify: 'Property type · Budget · Location',
    action: 'Assign the right agent',
    detail:
      'Capture what buyers are looking for, then match the enquiry with the person who knows the area.',
  },
  {
    name: 'Home services',
    problem: 'Quote requests arrive while the team is out on a job.',
    source: 'Quote request',
    qualify: 'Job type · Postcode · Timing',
    action: 'Arrange a site visit',
    detail:
      'Collect the job details first, flag urgent requests, and keep the next conversation focused.',
  },
  {
    name: 'Consultants',
    problem: 'Discovery time is valuable. Context makes it count.',
    source: 'Consultation enquiry',
    qualify: 'Challenge · Scope · Timeline',
    action: 'Book a discovery call',
    detail: 'Understand the challenge before the first call and keep potential engagements moving.',
  },
  {
    name: 'Healthcare / clinics',
    problem: 'Appointment enquiries need a clear administrative next step.',
    source: 'Appointment enquiry',
    qualify: 'Service · Timing · Contact',
    action: 'Booking follow-up',
    detail:
      'Organize appointment requests without collecting sensitive health information or making clinical decisions.',
  },
  {
    name: 'Professional services',
    problem: 'Different enquiries need different specialists.',
    source: 'Website enquiry',
    qualify: 'Service · Scope · Deadline',
    action: 'Route to a specialist',
    detail:
      'Build a consistent intake process that gives the right specialist the context they need.',
  },
];
export function SolutionsSelector({ full = false }: { full?: boolean }) {
  const [index, setIndex] = useState(0);
  const item = industries[index];
  return (
    <section className={full ? 'solutions-full' : 'section container'}>
      {!full && (
        <SectionTitle
          number="08"
          kicker="YOUR BUSINESS. YOUR FLOW."
          title="Built around how you work."
        />
      )}
      <div className="solutions-layout">
        <div
          className="industry-list"
          role="tablist"
          aria-label="Industries"
          onKeyDown={tabKeyboard}
        >
          {industries.map((industry, i) => (
            <button
              key={industry.name}
              role="tab"
              aria-selected={i === index}
              tabIndex={i === index ? 0 : -1}
              aria-controls="industry-panel"
              id={`industry-${i}`}
              onClick={() => setIndex(i)}
            >
              <span>0{i + 1}</span>
              {industry.name}
              <ArrowUpRight size={17} />
            </button>
          ))}
        </div>
        <div
          className="industry-panel"
          id="industry-panel"
          role="tabpanel"
          aria-labelledby={`industry-${index}`}
        >
          <p className="kicker">GROWORA FOR {item.name.toUpperCase()}</p>
          <h3>{item.problem}</h3>
          <p>{item.detail}</p>
          <div className="industry-flow">
            {[item.source, item.qualify, item.action].map((t, i) => (
              <div key={t}>
                <span>{['01 / SOURCE', '02 / QUALIFICATION', '03 / ACTION'][i]}</span>
                <strong>{t}</strong>
                {i < 2 && <ArrowRight size={18} />}
              </div>
            ))}
          </div>
          <div className="industry-automation">
            <Sparkles size={17} />
            <span>
              Example rule: when the enquiry is qualified, assign an owner and prepare a response.
            </span>
          </div>
          <Link href="/demo">
            Try this journey <ArrowUpRight size={14} />
          </Link>
        </div>
      </div>
    </section>
  );
}
export function IntegrationUniverse() {
  return (
    <section className="section container integration-universe">
      <div className="integration-copy">
        <p className="kicker">09 / PART OF YOUR ECOSYSTEM</p>
        <h2>
          One connected flow.
          <br />
          <span className="muted">Your familiar tools.</span>
        </h2>
        <p>
          Designed to connect with the tools your team already uses. Explore the integration
          concepts.
        </p>
        <ButtonLink href="/integrations" secondary>
          Explore integrations
        </ButtonLink>
        <span className="micro">CONCEPTUAL CONNECTIONS · NO LIVE SYNC</span>
      </div>
      <div className="integration-orbit">
        <div className="orbit-ring ring-one" />
        <div className="orbit-ring ring-two" />
        <div className="integration-hub">
          <Mark />
        </div>
        {integrations.slice(0, 6).map((item, i) => (
          <Link href="/integrations" className={`orbit-tool tool-${i}`} key={item.name}>
            <span>{item.symbol}</span>
            <small>{item.name}</small>
          </Link>
        ))}
      </div>
    </section>
  );
}
export function Pricing({ detailed = false }: { detailed?: boolean }) {
  const [annual, setAnnual] = useState(false);
  return (
    <section className={detailed ? 'pricing-full' : 'section container pricing-section'}>
      {!detailed && (
        <SectionTitle
          number="10"
          kicker="ROOM TO GROW"
          title="A plan for your next chapter."
          description="Start focused. Build momentum. Scale your process."
        />
      )}
      <div className="pricing-top">
        <span className="micro">ILLUSTRATIVE PRICING · NO CHECKOUT OR CHARGES</span>
        <div className="segmented" aria-label="Billing period">
          <button
            aria-pressed={!annual}
            className={!annual ? 'active' : ''}
            onClick={() => setAnnual(false)}
          >
            Monthly
          </button>
          <button
            aria-pressed={annual}
            className={annual ? 'active' : ''}
            onClick={() => setAnnual(true)}
          >
            Yearly <span>−20%</span>
          </button>
        </div>
      </div>
      <div className="pricing-grid">
        {[
          {
            name: 'Starter',
            price: 29,
            desc: 'Give every enquiry a better beginning.',
            features: [
              '250 leads / month',
              '3 smart capture forms',
              'Lead scoring & pipeline',
              '1 workspace member',
            ],
          },
          {
            name: 'Growth',
            price: 79,
            desc: 'Turn a good process into your advantage.',
            features: [
              '2,000 leads / month',
              'Unlimited capture forms',
              'Custom automation flows',
              '5 workspace members',
            ],
          },
          {
            name: 'Scale',
            price: 179,
            desc: 'More volume. The same clear direction.',
            features: [
              '10,000 leads / month',
              'Advanced routing rules',
              'Multiple team pipelines',
              '20 workspace members',
            ],
          },
        ].map((plan, i) => (
          <div className={`price-column ${i === 1 ? 'featured' : ''}`} key={plan.name}>
            <div className="plan-title">
              <span>{plan.name}</span>
              {i === 1 && <small>BUILT FOR MOMENTUM</small>}
            </div>
            <p>{plan.desc}</p>
            <div className="price">
              <strong>£{Math.round(plan.price * (annual ? 0.8 : 1))}</strong>
              <span>/ month</span>
            </div>
            <small className="billing-copy">
              {annual
                ? `£${Math.round(plan.price * 0.8) * 12} billed yearly`
                : 'Billed monthly · illustrative plan'}
            </small>
            <ButtonLink href={`/demo?plan=${plan.name.toLowerCase()}`} secondary={i !== 1}>
              Explore {plan.name}
            </ButtonLink>
            <ul>
              {plan.features.map((f) => (
                <li key={f}>
                  <Check size={15} />
                  {f}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      {detailed && (
        <>
          <div className="comparison-table table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Make the process yours</th>
                  <th>Starter</th>
                  <th>Growth</th>
                  <th>Scale</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ['Smart capture', '3 forms', 'Unlimited', 'Unlimited'],
                  ['Rule-based scoring', 'Included', 'Custom rules', 'Custom rules'],
                  ['Automation', '2 flows', '20 flows', 'Unlimited'],
                  ['Workspace members', '1', '5', '20'],
                  ['Pipeline views', '1', '3', 'Unlimited'],
                  ['Analytics', 'Overview', 'Source breakdown', 'Team breakdown'],
                ].map((row) => (
                  <tr key={row[0]}>
                    {row.map((v, i) => (i === 0 ? <th key={v}>{v}</th> : <td key={i}>{v}</td>))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="faq">
            <h3>A few good questions.</h3>
            {[
              [
                'Is this a live paid product?',
                'Growora is an interactive portfolio demonstration. Prices are illustrative. There is no checkout, subscription or payment collection.',
              ],
              [
                'What happens to the data I enter?',
                'Demo leads and workspace changes stay in your browser. No external service receives your form submissions.',
              ],
              [
                'Can I try every plan?',
                'Every demo workspace has the same interactive capabilities. Plan choices illustrate a possible commercial model.',
              ],
              [
                'Do integrations send real data?',
                'No. Integration controls demonstrate connection states only. No OAuth, email delivery or external sync is implemented.',
              ],
            ].map(([q, a]) => (
              <details key={q}>
                <summary>
                  {q}
                  <span>+</span>
                </summary>
                <p>{a}</p>
              </details>
            ))}
          </div>
        </>
      )}
    </section>
  );
}
export function Philosophy() {
  return (
    <section className="philosophy container">
      <span className="kicker">THE GROWORA PHILOSOPHY</span>
      <h2>
        Every lead deserves
        <br />
        <span>a next step.</span>
        <span className="philosophy-arrow">↗</span>
      </h2>
      <div>
        <span className="philosophy-index">G / 01</span>
        <p>
          A form submission shouldn’t be the end of a journey.
          <br />
          It should be the beginning of a clear process.
        </p>
        <Link href="/about">
          The thinking behind Growora <ArrowUpRight size={16} />
        </Link>
      </div>
    </section>
  );
}
