'use client';
import { useState } from 'react';
import { Check, GitBranch, Mail, Play, Timer, UserRound, Zap, Bell, Save } from 'lucide-react';
import { useLocalState } from '@/components/providers';
import { SectionTitle } from '@/components/ui';
const baseNodes = [
  {
    name: 'New lead captured',
    type: 'Trigger',
    icon: Zap,
    detail: 'Website enquiry form',
    value: 'Website enquiry',
  },
  {
    name: 'Budget above threshold?',
    type: 'Condition',
    icon: GitBranch,
    detail: 'Budget is greater than £2,000',
    value: '2000',
  },
  {
    name: 'Mark as high priority',
    type: 'Action',
    icon: Check,
    detail: 'Set priority to High',
    value: 'High',
  },
  {
    name: 'Assign sales owner',
    type: 'Action',
    icon: UserRound,
    detail: 'Route to Jamie Lee',
    value: 'Jamie Lee',
  },
  {
    name: 'Send first response',
    type: 'Action',
    icon: Mail,
    detail: 'Template: Welcome & next steps',
    value: 'Welcome & next steps',
  },
  {
    name: 'Wait before follow-up',
    type: 'Delay',
    icon: Timer,
    detail: 'Wait 1 day, then check for reply',
    value: '1',
  },
  {
    name: 'Notify if no reply',
    type: 'Notification',
    icon: Bell,
    detail: 'Notify the assigned owner',
    value: 'Assigned owner',
  },
];
export function AutomationEditor({ id = 'high-value' }: { id?: string }) {
  const nodes = baseNodes.map((node, index) => {
    const variants: Record<string, Record<number, Partial<typeof node>>> = {
      'instant-response': {
        0: { name: 'Enquiry received', detail: 'Any capture form', value: 'All forms' },
        1: {
          name: 'Has a valid email?',
          detail: 'Email address is present',
          value: 'Email is present',
        },
        2: {
          name: 'Prepare acknowledgement',
          detail: 'Use the enquiry context',
          value: 'Acknowledgement',
        },
        4: {
          name: 'Send first response',
          detail: 'Template: Thanks for reaching out',
          value: 'Thanks for reaching out',
        },
      },
      'no-response': {
        0: { name: 'Conversation started', detail: 'Lead moved to Contacted', value: 'Contacted' },
        1: {
          name: 'Reply still outstanding?',
          detail: 'No reply after first contact',
          value: 'No reply',
        },
        2: {
          name: 'Flag for follow-up',
          detail: 'Set follow-up status',
          value: 'Follow-up needed',
        },
        4: {
          name: 'Prepare useful follow-up',
          detail: 'Template: Your next step',
          value: 'Your next step',
        },
        5: { name: 'Wait before reminder', detail: 'Wait 3 days', value: '3' },
      },
      'demo-request': {
        0: { name: 'Demo request captured', detail: 'Product demo form', value: 'Demo request' },
        1: {
          name: 'Team needs a walkthrough?',
          detail: 'Lead volume above 50',
          value: 'Lead volume above 50',
        },
        2: {
          name: 'Qualify demo request',
          detail: 'Set type to Product demo',
          value: 'Product demo',
        },
        4: {
          name: 'Prepare booking invitation',
          detail: 'Template: Choose your time',
          value: 'Choose your time',
        },
      },
      nurture: {
        0: {
          name: 'Early-interest lead captured',
          detail: 'Lead marked for nurturing',
          value: 'Nurture lead',
        },
        1: {
          name: 'Still exploring?',
          detail: 'Timeline is Just exploring',
          value: 'Just exploring',
        },
        2: {
          name: 'Add to nurture journey',
          detail: 'Sequence: Project planning',
          value: 'Project planning',
        },
        4: {
          name: 'Prepare a helpful resource',
          detail: 'Template: Planning your project',
          value: 'Planning your project',
        },
        5: { name: 'Give the idea room', detail: 'Wait 7 days', value: '7' },
      },
    };
    return { ...node, ...variants[id]?.[index] };
  });
  const alternative = {
    name: id === 'high-value' ? 'Nurture sequence' : 'Alternative route',
    type: 'Action',
    icon: Mail,
    detail: 'Keep the lead in the nurture queue',
    value: 'Nurture queue',
  };
  const [selected, setSelected] = useState(1);
  const [values, setValues] = useLocalState<Record<string, string>>(`growora-automation-${id}`, {});
  const [enabled, setEnabled] = useLocalState(`growora-automation-enabled-${id}`, true);
  const [running, setRunning] = useState(false);
  const [saved, setSaved] = useState(false);
  const node = selected === 7 ? alternative : nodes[selected];
  const numericCondition = id === 'high-value' && selected === 1;
  const passes = id !== 'high-value' || 7500 > Number(values[1] ?? 2000);
  return (
    <div className={`automation-editor ${running ? 'simulating' : ''}`}>
      <div className="automation-toolbar">
        <span>
          <i className={enabled ? 'live-dot' : 'neutral-dot'} />{' '}
          {enabled ? 'Enabled in demo' : 'Paused'}
        </span>
        <div>
          <button
            className="text-button"
            onClick={() => {
              setEnabled(!enabled);
              setRunning(false);
            }}
          >
            {enabled ? 'Pause' : 'Enable'} flow
          </button>
          <button
            className="button small secondary"
            disabled={!enabled}
            onClick={() => {
              setRunning(!running);
            }}
          >
            <Play size={12} />
            {running ? 'Stop simulation' : 'Test flow'}
          </button>
        </div>
      </div>
      <div className="automation-layout">
        <div className="node-canvas">
          <span className="canvas-caption">{id.replaceAll('-', ' ').toUpperCase()} / WORKFLOW</span>
          <div className="node-chain">
            {nodes.map((n, i) => (
              <div className="node-step" key={n.name}>
                {i > 0 && (
                  <div className={`connector ${running && (passes || i < 2) ? 'flow' : ''}`}>
                    <span />
                    {i === 2 && <em>YES</em>}
                  </div>
                )}
                <button
                  className={`flow-node ${selected === i ? 'selected' : ''} ${running && (passes || i < 2) ? 'running' : ''}`}
                  style={{ '--delay': `${i * 0.35}s` } as React.CSSProperties}
                  onClick={() => {
                    setSelected(i);
                    setSaved(false);
                  }}
                >
                  <span className={`node-symbol type-${n.type.toLowerCase()}`}>
                    {n.type === 'Condition' ? (
                      <b>IF</b>
                    ) : n.type === 'Trigger' ? (
                      <b>IN</b>
                    ) : (
                      <n.icon size={16} />
                    )}
                  </span>
                  <span>
                    <small>{n.type.toUpperCase()}</small>
                    <strong>{n.name}</strong>
                    <em>{values[i] || n.detail}</em>
                  </span>
                  <span className="node-menu">···</span>
                </button>
                {i === 1 && (
                  <div
                    className={`branch-nurture ${running && !passes ? 'alternative-active' : ''}`}
                  >
                    <span>NO</span>
                    <button
                      onClick={() => {
                        setSelected(7);
                        setSaved(false);
                      }}
                    >
                      <Mail size={14} /> {alternative.name}
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="canvas-legend">
            <i className="live-dot" />
            {running
              ? `Sample £7,500 enquiry → ${passes ? 'primary route' : 'nurture route'} · no messages sent`
              : 'Select a node to configure its behaviour'}
          </div>
        </div>
        <aside className="node-settings">
          <p className="kicker">NODE SETTINGS</p>
          <span className="settings-icon">
            <node.icon size={25} />
          </span>
          <h3>{node.name}</h3>
          <p>
            {numericCondition
              ? 'Separate urgent opportunities from leads that need more time.'
              : 'Keep this step specific, so every lead has a clear next action.'}
          </p>
          <label>
            {selected === 1
              ? 'Minimum budget (£)'
              : selected === 5
                ? 'Delay (days)'
                : 'Configuration'}
            <input
              type={numericCondition || selected === 5 ? 'number' : 'text'}
              min={0}
              value={values[selected] ?? node.value}
              onChange={(e) => {
                setValues({ ...values, [selected]: e.target.value });
                setSaved(false);
              }}
            />
          </label>
          <button className="button small" onClick={() => setSaved(true)}>
            <Save size={14} />
            {saved ? 'Settings saved' : 'Save settings'}
          </button>
          <div className="settings-note">
            <Check size={15} />
            <span>
              Changes stay in this browser. Test flow visualizes the route without sending emails or
              notifications.
            </span>
          </div>
        </aside>
      </div>
    </div>
  );
}
export function AutomationSection() {
  return (
    <section id="automation" className="section container">
      <SectionTitle
        number="05"
        kicker="MOMENTUM, BUILT IN"
        title="Your best process. On repeat."
        description="Give every lead a path forward. Set the conditions, connect the steps, and let the routine work follow."
      />
      <AutomationEditor />
    </section>
  );
}
