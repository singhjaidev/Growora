# Growora — implementation checkpoint

**Updated: 29 September 2026**
**Current milestone: hero + first cinematic scroll sequence COMPLETE; ready for visual evaluation.**

## Authoritative direction

The user rejected both previous directions: the cobalt editorial hero and the neutral routing-board hero. The 29 September brief supersedes the historical design plan. Do not restore rails, gates, tickets or scattered first-screen labels. Do not restart the project or write another design-only plan.

Current direction: bright, minimal, contemporary sans typography and ONE dimensional lead-intelligence console. Headline: “Turn website visits into real opportunities.” The interface opens progressively into Capture → Qualify → Score → Route → Follow up → Convert. Preserve existing routes, domain logic and local persistence.

## Milestone A — replacement hero implemented and visually checked

- Replaced the rail/gate world with a single physical interface: rounded pearl surface, metallic rim, dark milled base, glass interlayer, restrained indigo score ring, studio lighting and soft shadow.
- One immediately readable headline, short supporting line and two usable CTAs. Workflow labels remain hidden until the story begins.
- Intro assembles the layers in two seconds. Pointer response is restrained. Pause/resume and replay remain available.
- Separate CSS 3D mobile composition; no mobile WebGL. Static fallback also covers reduced motion, data saving and unavailable WebGL.
- Inspected actual desktop WebGL at 1440×900 and mobile at 390×844. Revised desktop scale to create space beneath the CTA. Mobile first viewport contains the headline, both CTAs and the full interface object.
- Existing renderer telemetry sampled 33 draw calls / 9,512 triangles before the raised score ring was added. This is not a Lighthouse or GPU benchmark.

Changed files: `src/components/marketing/hero.tsx`, `src/components/three/lead-engine.tsx`, new `src/components/three/console-texture.ts`, new `src/components/visual/lead-console.tsx`, `src/lib/lead-story.ts`, and the hero block of `src/app/art-direction.css`. No dependency additions.

Recoverable source snapshot: `.checkpoints/before-console-revision-20260929.zip`. Earlier source snapshots remain in `.checkpoints`.

## Milestone B — implementation checkpoint before final verification (historical)

The same mounted console moves from the centred hero into the story composition. Its layers separate, the score ring lifts, the object turns toward the assigned owner, and the layers close into a qualified opportunity. Six interface states use the same illustrative Alex Morgan record; its 91 score derives from the existing qualifier. The final state is Qualified, never a fabricated Won result.

Desktop uses native bounded scrolling; mobile/short screens/reduced motion provide keyboard-accessible stage controls and a readable transcript. No scroll interception. Remaining checks: all six final states, reverse/release behavior, mobile stage fit, pause/offscreen lifecycle, final build/lint/typecheck/domain tests. Finish these before expanding to other homepage sections.

## Verification and data

- Latest typecheck passed after fixing the renderer closure nullability.
- Final build/typecheck/lint/tests passed; see the completion record below.
- Browser existing local demo records were not changed. No lead submissions, storage reset, settings changes or app mutations performed.
- Existing Next dev server at `http://localhost:3000`, process 26564. A duplicate launch detected the server and exited; do not launch another without checking.
- This directory has no Git repository. Use the snapshots for recovery.
- Installed Next lazy-loading documentation read; Three remains a dynamic client-only import.

## Next safe action

Finish Milestone B browser/automated checks, fix any actual issues, and update this checkpoint with verified results. This run prioritises a complete hero and scroll sequence. Existing app/product/demo functionality and later marketing sections are preserved; broader redesign is deferred.

## Milestone B — completed (29 September 2026, final verification)

Recovered the existing console implementation and finished its remaining responsive framing, replay behavior, mobile detail spacing, accessible non-WebGL score explanation and final verification. No new creative direction or later-section redesign was started.

### Final behavior

- One persistent WebGL console transforms across Capture, Qualify, Score, Route, Follow up and Convert. The camera reframes, glass/interface layers open, the physical score ring rises, the owner-facing surface turns, and the layers close into the qualified opportunity.
- Native desktop scroll spans 2,400px, reverses normally, and releases back into the document. Manual stage selection has an explicit Follow scroll action. A skip link reaches the existing lead demo.
- Hero entrance lasts two seconds; all links work immediately. Pause/resume stops/restarts the clock. Replay returns to the opening. The mobile/static version has six explicit stage controls instead of a long pinned runway.
- Mobile follow-up caption and final opportunity spacing were corrected. Narrow-desktop camera framing adapts to aspect ratio. Removed the unused old routing diagram and ticket components.

### Verification actually performed

- Desktop: visual review at 1440×900, 1440×800 and 1024×900. Actual production Three canvas rendered; checked every narrative state, physical forward/reverse scrolling, stage selection and release into the page.
- Mobile: hero and all six states inspected at 390×844; additional hero/final-state inspection at 320×740. No horizontal document overflow; no WebGL canvas on mobile. Stage targets are 44px high.
- Keyboard: ArrowRight and End stage selection, Tab leaving the tablist, visible focus, Enter on Follow scroll/Replay and the hero CTA. The CTA reached `#lead-demo`; no form was submitted.
- Accessibility: decorative canvas and fallback visual are hidden from the accessibility tree; HTML headings/descriptions remain available, inactive content is inert, stage buttons identify their panel, and score contributions have a text equivalent. A native details transcript contains all six stages.
- Lifecycle: renderer scene ID stayed unchanged across chapters and reverse scroll. Pause held the frame counter at 675 across separate observations. After the scene left the viewport, it held at 2726 across separate observations while the single canvas remained mounted.
- Production browser console: no error or warning entries in the final checked sample.
- `npm run build`: PASS, all 26 routes generated.
- `npm run typecheck`: PASS.
- `npm run lint`: PASS.
- `npm run test`: PASS, 5 tests / 0 failures.

### Performance and verification limits

One renderer, lazy-loaded only for eligible desktop screens. DPR capped at 1.5, falling to 1 after sustained high CPU render cost. Static soft-shadow texture, cached surface textures, no post-processing or additional libraries. Idle updates limited to approximately 24fps, time-based damping, visibility/offscreen stopping and full geometry/material/texture/environment disposal. Scene uses 33–34 draw calls depending on whether the raised score ring is shown.

Reduced-motion code and CSS were reviewed: no WebGL mounting, no pinned runway, no animation/transitions, immediate manual state changes, and the complete readable transcript. The browser tool does not expose media-preference emulation, so OS-level reduced-motion switching was **not browser-emulated**. Forced WebGL context loss, low-end hardware/GPU profiling, assistive-technology certification and production Lighthouse measurement were not performed. Do not claim those checks passed.

### Deliverables and exact next task

Screenshots are in `.checkpoints/console-review/`. Production preview is running at `http://localhost:3000` (terminal session 67750 during this run; confirm availability after interruption). Existing persisted browser records remained present; no lead, settings or storage mutations were performed. Product/app routes and all later marketing sections remain unchanged.

**Current milestone: implementation complete and ready for visual evaluation. Next task: apply the user's next visual feedback when provided. Do not restart, restore rails/gates, or proceed into other site areas automatically.**
