'use client';

import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import { leadPosition, routing, type HeroClock } from '@/lib/lead-story';

type EngineProps = {
  clock: HeroClock;
  active: boolean;
  onReadyChange: (ready: boolean) => void;
};

/** One demand-rendered enhancement of the same route used by the SVG. */
export default function LeadEngine({ clock, active, onReadyChange }: EngineProps) {
  const host = useRef<HTMLDivElement>(null);
  const activeRef = useRef(active);
  const readyCallback = useRef(onReadyChange);
  const redraw = useRef<(() => void) | null>(null);

  useEffect(() => { readyCallback.current = onReadyChange; }, [onReadyChange]);
  useEffect(() => {
    activeRef.current = active;
    if (active) redraw.current?.();
  }, [active]);

  useEffect(() => {
    const element = host.current;
    if (!element) return;
    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true, powerPreference: 'low-power' });
    } catch {
      readyCallback.current(false);
      return;
    }

    let dpr = Math.min(window.devicePixelRatio || 1, 1.25);
    renderer.setPixelRatio(dpr);
    renderer.setClearColor(0x2447d8, 0);
    renderer.shadowMap.enabled = false;
    renderer.domElement.setAttribute('aria-hidden', 'true');
    renderer.domElement.style.cssText = 'display:block;width:100%;height:100%';
    element.appendChild(renderer.domElement);

    const scene = new THREE.Scene();
    const elevation = THREE.MathUtils.degToRad(55);
    const yaw = THREE.MathUtils.degToRad(18);
    const sine = Math.sin(elevation);
    const cosine = Math.cos(elevation);
    const sinYaw = Math.sin(yaw);
    const cosYaw = Math.cos(yaw);
    const camera = new THREE.OrthographicCamera(-640, 640, 150, -150, .1, 5000);
    camera.position.set(-sinYaw * cosine * 1800, sine * 1800, cosYaw * cosine * 1800);
    camera.lookAt(0, 0, 0);
    camera.updateMatrixWorld();

    scene.add(new THREE.AmbientLight(0xffffff, 1.65));
    const key = new THREE.DirectionalLight(0xfff8e8, 2.1);
    key.position.set(-450, 900, 600);
    scene.add(key);

    // Four shared materials, two lights, no textures or shadow passes.
    const paper = new THREE.MeshStandardMaterial({ color: 0xf3f0e8, roughness: .78, metalness: .05 });
    const neutral = new THREE.MeshBasicMaterial({ color: 0x9fb6ee });
    const signal = new THREE.MeshBasicMaterial({ color: 0xff8259 });
    const depth = new THREE.MeshBasicMaterial({ color: 0x17309a });
    const materials = [paper, neutral, signal, depth];
    const geometries = new Set<THREE.BufferGeometry>();
    const unitBox = new THREE.BoxGeometry(1, 1, 1);
    geometries.add(unitBox);

    // Inverse fixed-camera projection: all physical objects share SVG anchors.
    function at(x: number, y: number, objectHeight = 0) {
      const screenX = x - routing.width / 2;
      const screenY = routing.height / 2 - y - objectHeight * cosine;
      return new THREE.Vector3(
        cosYaw * screenX + sinYaw * screenY / sine,
        objectHeight,
        sinYaw * screenX - cosYaw * screenY / sine,
      );
    }

    function mergedBoxes(boxes: Array<[number, number, number, number, number, number]>) {
      const pieces = boxes.map(([w, h, d, x, y, z]) => {
        const geometry = new THREE.BoxGeometry(w, h, d);
        geometry.translate(x, y, z);
        return geometry;
      });
      const geometry = mergeGeometries(pieces)!;
      pieces.forEach((piece) => piece.dispose());
      geometries.add(geometry);
      return geometry;
    }

    function flatSegments(paths: ReadonlyArray<readonly (readonly number[])[]>, thickness: number, material: THREE.Material, objectHeight = 0) {
      const pieces: THREE.BufferGeometry[] = [];
      paths.forEach((points) => {
        for (let i = 1; i < points.length; i++) {
          const start = at(points[i - 1][0], points[i - 1][1], objectHeight);
          const end = at(points[i][0], points[i][1], objectHeight);
          const direction = end.clone().sub(start);
          const geometry = new THREE.BoxGeometry(direction.length(), 1, thickness);
          geometry.applyQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), direction.normalize()));
          geometry.translate((start.x + end.x) / 2, objectHeight, (start.z + end.z) / 2);
          pieces.push(geometry);
        }
      });
      const geometry = mergeGeometries(pieces)!;
      pieces.forEach((piece) => piece.dispose());
      geometries.add(geometry);
      const mesh = new THREE.Mesh(geometry, material);
      scene.add(mesh);
      return mesh;
    }

    flatSegments([routing.secondary, routing.third, routing.discovery, routing.nurture], 1.8, neutral);
    flatSegments([routing.main], 5, depth, .3);
    const gateGeometry = mergedBoxes([
      [16.8, 220, 17, 8.4, 110, 0],
      [80, 20, 17, 40, 210, 0],
      [16.8, 220, 17, 71.6, 110, 0],
    ]);
    const footGeometry = mergedBoxes([[99, 7, 31, 42, 1.5, 1]]);
    const shadowGeometry = mergedBoxes([[116, .6, 38, 48, -1.5, 12]]);
    const gateAssemblies = routing.gates.map((x) => {
      const group = new THREE.Group();
      group.position.copy(at(x - 30, 178));
      const frame = new THREE.Mesh(gateGeometry, paper);
      group.add(frame, new THREE.Mesh(footGeometry, neutral), new THREE.Mesh(shadowGeometry, depth));
      scene.add(group);
      return frame;
    });

    const ticks: number[][][] = [];
    for (let i = 0; i < 9; i++) ticks.push([[746 + i * 15, 166], [746 + i * 15, i % 2 ? 173 : 178]]);
    flatSegments(ticks, 1.6, neutral, .5);
    const junction = new THREE.Mesh(unitBox, paper);
    junction.position.copy(at(900, 150, 3));
    junction.scale.set(17, 5, 17);
    junction.rotation.y = Math.PI / 4;
    scene.add(junction);

    const routeSegments = routing.main.slice(1).map((point, i) => {
      const start = at(routing.main[i][0], routing.main[i][1], 1.4);
      const end = at(point[0], point[1], 1.4);
      const vector = end.clone().sub(start);
      return { start, vector, length: vector.length(), rotation: new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(1, 0, 0), vector.clone().normalize()) };
    });
    const activeRoute = new THREE.InstancedMesh(unitBox, signal, routeSegments.length);
    activeRoute.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    activeRoute.frustumCulled = false;
    scene.add(activeRoute);
    const gateLights = new THREE.InstancedMesh(unitBox, signal, routing.gates.length);
    gateLights.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    gateLights.frustumCulled = false;
    scene.add(gateLights);

    const ticketShape = new THREE.Shape();
    ticketShape.moveTo(-32, 20);
    ticketShape.lineTo(20, 20);
    ticketShape.lineTo(32, 8);
    ticketShape.lineTo(32, -20);
    ticketShape.lineTo(-32, -20);
    ticketShape.closePath();
    const ticketGeometry = new THREE.ExtrudeGeometry(ticketShape, { depth: 7, steps: 1, bevelEnabled: false, curveSegments: 1, material: 0, extrudeMaterial: 1 });
    geometries.add(ticketGeometry);
    const ticket = new THREE.Group();
    ticket.quaternion.copy(camera.quaternion);
    ticket.rotateY(-.22);
    ticket.rotateX(.1);
    ticket.add(new THREE.Mesh(ticketGeometry, [signal, depth]));
    ticket.add(new THREE.Mesh(mergedBoxes([
      [27, 2, .4, -5.5, 6, 7.3],
      [37, 2, .4, -.5, -3, 7.3],
      [19, 2, .4, -9.5, -12, 7.3],
    ]), depth));
    scene.add(ticket);

    const transform = new THREE.Object3D();
    let progress = clock.getSnapshot();
    let visible = true;
    let contextLost = false;
    let ready = false;
    let disposed = false;
    let width = 0;
    let height = 0;
    let previousProgress = progress;
    let previousTime = 0;
    let lastDraw = 0;
    let measuredFrames = 0;
    let measuredTime = 0;
    let throttle = false;

    function setReady(value: boolean) {
      element!.dataset.loaded = String(value);
      if (ready !== value) { ready = value; readyCallback.current(value); }
    }

    function updateScene() {
      const position = leadPosition(progress);
      ticket.position.copy(at(position.x, position.y, 16));
      // Gate response is caused by this ticket's arrival, then holds still.
      const arrivals = [.27, .4, .53];
      gateAssemblies.forEach((frame, i) => {
        const response = Math.max(0, Math.min(1, (progress - arrivals[i]) / .075));
        frame.position.y = Math.sin(response * Math.PI) * 5;
        transform.position.copy(at(routing.gates[i] - 23, 137, 52));
        transform.quaternion.copy(camera.quaternion);
        transform.scale.set(5, progress >= arrivals[i] ? 26 : 5, 1.5);
        transform.updateMatrix();
        gateLights.setMatrixAt(i, transform.matrix);
      });
      gateLights.instanceMatrix.needsUpdate = true;

      routeSegments.forEach((segment, i) => {
        const endpoint = routing.main[i + 1];
        const beginning = routing.main[i];
        const portion = Math.max(0, Math.min(1, (position.x - beginning[0]) / (endpoint[0] - beginning[0])));
        transform.position.copy(segment.start).addScaledVector(segment.vector, portion / 2);
        transform.quaternion.copy(segment.rotation);
        transform.scale.set(Math.max(.001, segment.length * portion), 1.5, 3.3);
        transform.updateMatrix();
        activeRoute.setMatrixAt(i, transform.matrix);
      });
      activeRoute.instanceMatrix.needsUpdate = true;
    }

    function draw(force = false) {
      if (disposed || contextLost || !activeRef.current || !visible || document.hidden || !width || !height) {
        previousTime = 0;
        return;
      }
      const now = performance.now();
      const advancing = progress > previousProgress && progress - previousProgress < .1;
      if (!force && throttle && advancing && progress < 1 && now - lastDraw < 1000 / 30) return;
      if (advancing && previousTime && now - previousTime < 150) {
        measuredFrames += 1;
        measuredTime += now - previousTime;
        if (measuredFrames >= 120) {
          if (measuredTime / measuredFrames > 24) {
            if (dpr > 1) { dpr = 1; renderer.setPixelRatio(dpr); renderer.setSize(width, height, false); }
            else throttle = true;
          }
          measuredFrames = 0;
          measuredTime = 0;
        }
      }
      previousTime = now;
      previousProgress = progress;
      lastDraw = now;
      updateScene();
      try {
        renderer.render(scene, camera);
        element!.dataset.drawCalls = String(renderer.info.render.calls);
        element!.dataset.triangles = String(renderer.info.render.triangles);
        element!.dataset.dpr = String(dpr);
        element!.dataset.fpsLimit = throttle ? '30' : 'none';
        element!.dataset.progress = progress.toFixed(4);
        setReady(true);
      } catch { contextLost = true; setReady(false); }
    }

    function resize() {
      const rect = element!.getBoundingClientRect();
      width = rect.width;
      height = rect.height;
      if (!width || !height) return;
      renderer.setSize(width, height, false);
      // Match SVG xMidYMid meet at every desktop aspect ratio.
      const scale = Math.min(width / routing.width, height / routing.height);
      camera.left = -width / scale / 2;
      camera.right = width / scale / 2;
      camera.top = height / scale / 2;
      camera.bottom = -height / scale / 2;
      camera.updateProjectionMatrix();
      draw(true);
    }

    const unsubscribe = clock.subscribe((value) => { progress = value; draw(); });
    redraw.current = () => draw(true);
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(element);
    const intersectionObserver = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (visible) draw(true); else previousTime = 0;
    });
    intersectionObserver.observe(element);
    const onVisibility = () => { previousTime = 0; if (!document.hidden) draw(true); };
    const onContextLost = (event: Event) => { event.preventDefault(); contextLost = true; setReady(false); };
    const onContextRestored = () => { contextLost = false; previousTime = 0; draw(true); };
    document.addEventListener('visibilitychange', onVisibility);
    renderer.domElement.addEventListener('webglcontextlost', onContextLost);
    renderer.domElement.addEventListener('webglcontextrestored', onContextRestored);
    resize();

    return () => {
      disposed = true;
      redraw.current = null;
      unsubscribe();
      resizeObserver.disconnect();
      intersectionObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibility);
      renderer.domElement.removeEventListener('webglcontextlost', onContextLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onContextRestored);
      setReady(false);
      activeRoute.dispose();
      gateLights.dispose();
      geometries.forEach((geometry) => geometry.dispose());
      materials.forEach((material) => material.dispose());
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, [clock]);

  return <div className="routing-webgl" ref={host} aria-hidden="true" style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} />;
}
