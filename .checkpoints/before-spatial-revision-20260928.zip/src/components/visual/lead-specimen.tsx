import { Check, CornerDownRight } from 'lucide-react';
import { money } from '@/lib/domain';
import { storyLead, storyStages } from '@/lib/lead-story';

// One stable ticket, never keyed by its stage. All six presentations are views
// of the canonical illustrative input, never fixture or provider records.
export function LeadSpecimen({ stage }: { stage: number }) {
  return (
    <div className="lead-specimen" data-stage={stage} aria-label={`Illustrative lead, ${storyLead.name}. ${storyStages[stage]} stage.`}>
      <div className="specimen-registration"><span>GROWORA / LEAD RECORD</span><span>ILLUSTRATIVE</span></div>
      <svg className="specimen-routing" viewBox="0 0 760 460" fill="none" preserveAspectRatio="none" aria-hidden="true">
        <path className="specimen-idle-rail" d="M0 193H590L630 125H760M590 193L630 215H760M590 193L630 305H760" />
        <path className="specimen-entry-rail" d="M0 193H120" />
        <path className="specimen-chosen-rail" pathLength="1" d="M385 193H590L630 125H760" />
        <path className="specimen-follow-rail" pathLength="1" d="M670 130V353L645 378H150" />
        <path className="specimen-closed-rail" pathLength="1" d="M150 378H100L75 353V275" />
      </svg>
      <div className="specimen-guide" aria-hidden="true"><i /><i /><i /></div>
      <article className="specimen-ticket">
        <div className="specimen-ticket-top"><strong>{storyLead.reference}</strong><span>{stage === 5 ? 'OPPORTUNITY' : stage >= 3 ? 'QUALIFIED LEAD' : 'WEBSITE ENQUIRY'}</span></div>
        <div className="specimen-identity"><h4>{storyLead.name}</h4><p>{storyLead.company}</p><span>{storyLead.service}</span></div>
        <dl className="specimen-facts"><div><dt>Budget</dt><dd>{storyLead.budget}<Check aria-hidden="true" /></dd></div><div><dt>Timing</dt><dd>{storyLead.timeline}<Check aria-hidden="true" /></dd></div><div><dt>Company</dt><dd>Context supplied<Check aria-hidden="true" /></dd></div></dl>
        <div className="specimen-ticket-foot"><span>{stage >= 3 ? storyLead.owner : 'Ready for the next step'}</span><strong>{stage === 5 ? <><Check size={15} /> Won · {money(storyLead.value)}</> : stage >= 2 ? `${storyLead.score} / 100` : '→'}</strong></div>
      </article>
      <div className="specimen-destinations" aria-hidden={stage < 3}>
        <div className="specimen-priority"><span>≥75 / PRIORITY</span><strong>Jamie Lee <CornerDownRight size={14} /></strong></div><div><span>55–74</span><strong>Discovery</strong></div><div><span>&lt;55</span><strong>Nurture</strong></div>
      </div>
      <div className="specimen-score" aria-hidden={stage < 2}>
        <div className="specimen-score-title"><span>INTENT INDEX</span><strong>{storyLead.score}<small> / 100</small></strong></div>
        <div className="specimen-ruler" role="meter" aria-label="Intent index" aria-valuemin={0} aria-valuemax={100} aria-valuenow={storyLead.score} aria-valuetext={`${storyLead.score} out of 100, High intent`}><i /><b style={{ left: `${storyLead.score}%` }} /><span className="ruler-threshold threshold-55">55</span><span className="ruler-threshold threshold-75">75</span></div>
        <p>30 base + 35 budget + 21 timing + 5 company</p>
      </div>
      <div className="specimen-followup" aria-hidden={stage < 4}><span><Check size={14} /> First response prepared</span><span>+1 day <b>Reminder scheduled</b></span></div>
      <div className="specimen-outcome" aria-hidden={stage !== 5}><Check size={16} /><span>Proposal → Won <b>Illustrative outcome</b></span></div>
      <span className="specimen-source">ONE OPPORTUNITY. CONTEXT INTACT.</span>
    </div>
  );
}
