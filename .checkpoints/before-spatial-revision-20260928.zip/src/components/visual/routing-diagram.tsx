import { routing, routePath, storyLead } from '@/lib/lead-story';

export function RoutingDiagram() {
  return (
    <svg className="routing-art" viewBox="0 0 1280 300" fill="none" aria-hidden="true">
      <g className="routing-geometry">
        <path d={routePath(routing.secondary)} className="route-passive" />
        <path d={routePath(routing.third)} className="route-passive" />
        <path d={routePath(routing.discovery)} className="route-passive" />
        <path d={routePath(routing.nurture)} className="route-passive" />
        <path d={routePath(routing.main)} className="route-bed" />
        <path d={routePath(routing.main)} className="route-selected" pathLength="1" />
        {routing.gates.map((x, i) => (
          <g className="route-gate" key={x} data-gate={i}>
            <path d={`M${x-32} 199 L${x+78} 166 L${x+78} 181 L${x-32} 214 Z`} fill="#17309a" />
            <path d={`M${x-30} 178 L${x+29} 153 L${x+29} 166 L${x-30} 191 Z`} fill="#b9c8de" />
            <path d={`M${x-30} 178 V52 L${x+16} 32 H${x+46} V151 L${x+30} 158 V52 H${x+20} L${x-14} 68 V172 Z`} fill="#f3f0e8" />
            <path d={`M${x-14} 68 L${x+20} 52 V158 L${x+4} 165 V77 L${x-14} 85 Z`} fill="#adbcd8" />
            <path d={`M${x+30} 52 L${x+46} 32 V151 L${x+30} 158 Z`} fill="#d2dae2" />
            <path d={`M${x-27} 51 L${x+17} 31 H${x+47}`} stroke="#fff" strokeWidth="2" />
            <path d={`M${x-24} 125 V151`} stroke="#ff8259" strokeWidth="5" className="gate-light" />
          </g>
        ))}
        <g className="route-calibration" stroke="#c0cdf6">
          {Array.from({ length: 9 }, (_, i) => <path key={i} d={`M${746+i*15} 166 v${i%2 ? 7:12}`} />)}
        </g>
        <path d="M890 150 l10 -10 10 10 -10 10 Z" fill="#f3f0e8" />
        <g className="desktop-signal" transform="translate(1150 65)">
          <path d="M-32 -20 H20 L32 -8 V20 H-32 Z" fill="#152f97" transform="translate(5 6)" />
          <path d="M-32 -20 H20 L32 -8 V20 H-32 Z" fill="#ff8259" />
          <path d="M-19 -6 H8 M-19 3 H18 M-19 12 H0" stroke="#252c29" strokeWidth="2" />
        </g>
      </g>
    </svg>
  );
}

export function MobileRoutingDiagram({ resolved = true }: { resolved?: boolean }) {
  return (
    <div className="mobile-routing">
      <div className="mobile-ports"><span>Website enquiry</span><span>Project</span><span>Conversation</span></div>
      <svg viewBox="0 0 350 216" fill="none" aria-hidden="true">
        <path d="M52 0 V182 H350 M176 0 V20 L52 65 M293 0 V20 L52 80" stroke="#90a9f0" strokeWidth="1.5" />
        <path d="M52 0 V150 L86 182 H350" stroke="#ff8259" strokeWidth="3" />
        {[44, 78, 112].map((y, i) => <g key={y} className="mobile-gate" data-gate={i}><path d={`M28 ${y+7} V${y-7} H75 V${y+7}`} stroke="#f3f0e8" strokeWidth="7" /><path d={`M28 ${y+7} V${y-7}`} stroke="#ff8259" strokeWidth="7" /></g>)}
        <g className="mobile-signal" transform="translate(275 182)"><path d="M-21 -14 H12 L21 -5 V14 H-21 Z" fill="#ff8259" /><path d="M-12 -4 H5 M-12 4 H10" stroke="#252c29" strokeWidth="2" /></g>
      </svg>
      <div className="mobile-gate-labels"><span>Context</span><span>Budget</span><span>Timing</span></div>
      <div className="mobile-route-score"><strong>{resolved ? storyLead.score : '—'}</strong><span>/ 100<br />{resolved ? 'High intent' : 'Reading'}</span></div>
      <div className="mobile-destination"><span>Priority sales → Jamie Lee</span><small>Contact within 10 minutes</small></div>
    </div>
  );
}
