'use client';
import dynamic from 'next/dynamic';
import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUpRight, Pause, Play, RotateCcw } from 'lucide-react';
import { ButtonLink } from '@/components/ui';
import { leadPosition, storyLead } from '@/lib/lead-story';
import { RoutingDiagram, MobileRoutingDiagram } from '@/components/visual/routing-diagram';
const Engine = dynamic(() => import('@/components/three/lead-engine'), { ssr: false });

export function Hero() {
  const host = useRef<HTMLElement>(null);
  const controls = useRef({ pause: () => {}, resume: () => {}, replay: () => {} });
  const [clock] = useState(() => {
    let progress = 1;
    const listeners = new Set<(value: number) => void>();
    return {
      getSnapshot: () => progress,
      subscribe: (listener: (value: number) => void) => { listeners.add(listener); return () => { listeners.delete(listener); }; },
      publish: (value: number) => { progress = value; listeners.forEach((listener) => listener(value)); },
    };
  });
  const [show3d, setShow3d] = useState(false);
  const [active, setActive] = useState(false);
  const [ready, setReady] = useState(false);
  const [paused, setPaused] = useState(false);
  const [phase, setPhase] = useState(4);
  useEffect(() => {
    const element = host.current;
    if (!element) return;
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    const desktop = matchMedia('(min-width: 1024px)');
    const mobile = matchMedia('(max-width: 699px)');
    const duration = mobile.matches ? 2300 : 3200;
    const connection = (navigator as Navigator & { connection?: { saveData?: boolean } }).connection;
    let visible = false;
    let stopped = false;
    let elapsed = 0;
    let lastTime = 0;
    let frame = 0;
    let phaseNow = -1;
    const signal = element.querySelector<SVGGElement>('.desktop-signal');
    const mobileSignal = element.querySelector<SVGGElement>('.mobile-signal');
    const route = element.querySelector<SVGPathElement>('.route-selected');
    const draw = (p: number) => {
      const point = leadPosition(p);
      signal?.setAttribute('transform', `translate(${point.x} ${point.y})`);
      const mp = p < .72 ? { x: 52, y: 8 + p / .72 * 142 } : p < .8 ? { x: 52 + (p - .72) / .08 * 34, y: 150 + (p - .72) / .08 * 32 } : { x: 86 + (p - .8) / .2 * 189, y: 182 };
      mobileSignal?.setAttribute('transform', `translate(${mp.x} ${mp.y})`);
      if (route) { route.style.strokeDasharray = '1'; route.style.strokeDashoffset = String(1 - p); }
      const next = p < .2 ? 0 : p < .57 ? 1 : p < .74 ? 2 : p < 1 ? 3 : 4;
      if (next !== phaseNow) { phaseNow = next; setPhase(next); }
      element.querySelectorAll<SVGElement>('[data-gate]').forEach((gate) => {
        gate.dataset.resolved = String(p >= .27 + Number(gate.dataset.gate) * .13);
      });
      clock.publish(p);
    };
    const canRun = () => visible && !document.hidden && !stopped && !reduced.matches;
    const tick = (time: number) => {
      frame = 0;
      if (!canRun()) return;
      elapsed += lastTime ? Math.min(64, time - lastTime) : 0;
      lastTime = time;
      const p = Math.min(1, elapsed / duration);
      draw(p);
      if (p < 1) frame = requestAnimationFrame(tick);
    };
    const sync = () => {
      cancelAnimationFrame(frame); frame = 0; lastTime = 0;
      setActive(visible && !document.hidden && !stopped && !reduced.matches);
      setShow3d(desktop.matches && !reduced.matches && !connection?.saveData && visible);
      if (reduced.matches) { elapsed = 3200; draw(1); }
      else if (canRun() && elapsed < duration) frame = requestAnimationFrame(tick);
    };
    controls.current = {
      pause: () => { stopped = true; sync(); },
      resume: () => { stopped = false; sync(); },
      replay: () => { elapsed = 0; stopped = false; draw(reduced.matches ? 1 : 0); sync(); },
    };
    draw(reduced.matches ? 1 : 0);
    const observer = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; sync(); }, { threshold: .05 });
    observer.observe(element);
    reduced.addEventListener('change', sync);
    desktop.addEventListener('change', sync);
    mobile.addEventListener('change', sync);
    document.addEventListener('visibilitychange', sync);
    return () => {
      cancelAnimationFrame(frame); observer.disconnect();
      reduced.removeEventListener('change', sync); desktop.removeEventListener('change', sync); mobile.removeEventListener('change', sync);
      document.removeEventListener('visibilitychange', sync);
    };
  }, [clock]);
  return (
    <section ref={host} className="momentum-hero" aria-labelledby="hero-title" data-phase={phase} data-renderer={ready && show3d ? 'webgl' : 'svg'}>
      <div className="momentum-inner">
        <div className="momentum-edition"><span>The lead conversion system</span><span>Interest in. Opportunity out.</span></div>
        <h1 id="hero-title"><span>Good leads deserve</span><em>a clear next step.</em></h1>
        <div className="momentum-intro">
          <p>Capture the context. Find the intent.<br />Turn the next hello into your next opportunity.</p>
          <div className="momentum-actions"><ButtonLink href="#lead-demo">Try a lead</ButtonLink><a href="#workflow">See the route <ArrowDown size={17} /></a></div>
          <span className="momentum-ref"><i /> One lead. Every possibility.</span>
        </div>
        <div className="momentum-machine" role="img" aria-label={`Illustrative lead: ${storyLead.name}. Context, budget and timing qualify a score of ${storyLead.score} out of 100. Priority sales queue, ${storyLead.owner}. ${storyLead.action}.`}>
          <RoutingDiagram />
          {show3d && <Engine clock={clock} active={active} onReadyChange={setReady} />}
          <div className="machine-input"><span>01 / CAPTURE</span><strong>Every opportunity<br />starts somewhere.</strong><small>Website enquiry →</small></div>
          <div className="machine-gate-labels"><span>Context <b>✓</b></span><span>Budget <b>✓</b></span><span>Timing <b>✓</b></span></div>
          <div className="machine-score"><span>{phase < 2 ? 'READING THE SIGNAL' : 'INTENT INDEX'}</span><strong>{phase < 2 ? '—' : storyLead.score}<small>/100</small></strong></div>
          <div className="machine-terminal"><span>03 / NEXT STEP</span><strong>Priority sales <ArrowUpRight size={18} /></strong><small>Jamie Lee · Contact within 10 minutes</small></div>
          <div className="machine-alternatives"><span>55–74 / Discovery</span><span>&lt;55 / Nurture</span></div>
          <MobileRoutingDiagram resolved={phase >= 2} />
        </div>
        <div className="momentum-baseline"><span><i /> G / 001 <b>Alex Morgan · Illustrative lead</b></span><a href="#workflow">Follow one opportunity <ArrowDown size={16} /></a><div className="hero-motion-controls"><button aria-label={paused ? 'Resume motion' : 'Pause motion'} onClick={() => { if (paused) controls.current.resume(); else controls.current.pause(); setPaused(!paused); }} aria-pressed={paused}>{paused ? <Play size={13} /> : <Pause size={13} />}<span>{paused ? 'Resume motion' : 'Pause motion'}</span></button><button aria-label="Replay route" onClick={() => { controls.current.replay(); setPaused(false); }}><RotateCcw size={13} /><span>Replay</span></button></div></div>
      </div>
      <div className="hero-exit" aria-hidden="true"><span>INTEREST</span><i /><span>OPPORTUNITY <ArrowDown size={18} /></span></div>
    </section>
  );
}
