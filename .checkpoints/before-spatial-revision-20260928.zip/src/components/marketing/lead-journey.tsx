'use client';

import { useEffect, useId, useRef, useState } from 'react';
import { ArrowDown, ArrowLeft, ArrowRight } from 'lucide-react';
import { tabKeyboard } from '@/components/ui';
import { LeadSpecimen } from '@/components/visual/lead-specimen';
import { storyStages } from '@/lib/lead-story';

const chapters = [
  { title: 'A hello, with context.', description: 'A name. A project. A timescale. Collect the details that make a useful first conversation.', receipt: 'Website enquiry received' },
  { title: 'Find the intent in the details.', description: 'Budget, timing and company become clear signals. The project gives the conversation context.', receipt: 'Three signals resolved' },
  { title: 'A score you can explain.', description: '30 base + 35 budget + 21 timing + 5 company. Clear rules, with a clear reason behind the result.', receipt: '91 / 100 · High intent' },
  { title: 'The right person. A clear next step.', description: 'Scores of 75 and above join the priority queue. Alex goes to Jamie, ready for a first conversation.', receipt: 'Priority sales → Jamie Lee' },
  { title: 'Keep the conversation moving.', description: 'Prepare a first response. Schedule a reminder. Give a good opportunity somewhere to go next.', receipt: 'Simulation · Reminder scheduled' },
  { title: 'Carry the context all the way.', description: 'From a first hello to a proposal, then a possible win. The same opportunity, with its story intact.', receipt: 'Illustrative outcome · £7,500 won' },
];

const TRAVEL = 1800;
const clamp = (value: number) => Math.max(0, Math.min(1, value));

// The only per-frame work is on this local presentation surface. The lead store
// is deliberately not a dependency of this illustrative chapter.
function paintProgress(element: HTMLElement, progress: number) {
  const phase = clamp(progress) * 6;
  const resolved = (index: number) => clamp((phase - index - 0.2) / 0.6);
  const movement = Array.from({ length: 6 }, (_, index) => resolved(index)).reduce((a, b) => a + b, 0) / 6;
  element.style.setProperty('--journey-progress', String(progress));
  element.style.setProperty('--ticket-x', `${movement * 40}px`);
  element.style.setProperty('--ticket-y', `${12 - movement * 24}px`);
  element.style.setProperty('--qualify-progress', String(resolved(1)));
  element.style.setProperty('--score-progress', String(resolved(2)));
  element.style.setProperty('--route-progress', String(resolved(3)));
  element.style.setProperty('--follow-progress', String(resolved(4)));
  element.style.setProperty('--convert-progress', String(resolved(5)));
}

export function LeadJourney({ mode = 'scroll' }: { mode?: 'scroll' | 'manual' }) {
  const [stage, setStage] = useState(0);
  const [pinned, setPinned] = useState(false);
  const [manual, setManual] = useState(false);
  const trackRef = useRef<HTMLDivElement>(null);
  const panelContentRef = useRef<HTMLDivElement>(null);
  const manualRef = useRef(false);
  const drawRef = useRef<() => void>(() => {});
  const id = useId();

  useEffect(() => {
    const track = trackRef.current;
    const content = panelContentRef.current;
    if (!track || !content) return;

    const desktop = matchMedia('(min-width: 1024px) and (min-height: 740px)');
    const reduced = matchMedia('(prefers-reduced-motion: reduce)');
    let eligible = false;
    let visible = false;
    let top = 0;
    let frame = 0;
    let disposed = false;

    const draw = () => {
      frame = 0;
      if (!eligible || manualRef.current || document.hidden) return;
      const progress = clamp((window.scrollY - top + 88) / TRAVEL);
      paintProgress(track, progress);
      setStage(Math.min(5, Math.floor(progress * 6)));
    };
    const schedule = () => {
      if (!frame && eligible && visible && !document.hidden) frame = requestAnimationFrame(draw);
    };
    drawRef.current = () => {
      if (!frame) frame = requestAnimationFrame(draw);
    };

    const measure = () => {
      if (disposed) return;
      const available = Math.min(680, window.innerHeight - 112);
      eligible = mode === 'scroll' && desktop.matches && !reduced.matches && content.scrollHeight <= available;
      track.style.setProperty('--journey-panel-height', `${available}px`);
      setPinned(eligible);
      top = track.getBoundingClientRect().top + window.scrollY;
      if (reduced.matches) {
        manualRef.current = false;
        setManual(false);
        setStage(5);
        paintProgress(track, 1);
      } else if (eligible) {
        schedule();
      }
    };
    const observer = new IntersectionObserver(([entry]) => {
      visible = entry.isIntersecting;
      if (!visible && manualRef.current) {
        manualRef.current = false;
        setManual(false);
      }
      if (visible) schedule();
    });
    observer.observe(track);
    const resize = new ResizeObserver(measure);
    resize.observe(content);
    window.addEventListener('scroll', schedule, { passive: true });
    window.addEventListener('resize', measure);
    document.addEventListener('visibilitychange', schedule);
    desktop.addEventListener('change', measure);
    reduced.addEventListener('change', measure);
    void document.fonts.ready.then(measure);
    measure();

    return () => {
      disposed = true;
      cancelAnimationFrame(frame);
      observer.disconnect();
      resize.disconnect();
      window.removeEventListener('scroll', schedule);
      window.removeEventListener('resize', measure);
      document.removeEventListener('visibilitychange', schedule);
      desktop.removeEventListener('change', measure);
      reduced.removeEventListener('change', measure);
      drawRef.current = () => {};
    };
  }, [mode]);

  function select(next: number) {
    manualRef.current = true;
    setManual(true);
    setStage(next);
    if (trackRef.current) paintProgress(trackRef.current, (next + 0.9) / 6);
  }

  return (
    <section className="lead-journey container" id="workflow" aria-labelledby={`${id}-title`}>
      <div className="journey-heading">
        <div><p className="journey-eyebrow">01 / FOLLOW ONE OPPORTUNITY</p><h2 id={`${id}-title`}>One lead.<br /><em>Every next step.</em></h2></div>
        <div><p>Follow Alex from first interest to a possible win.<br />Six decisions. One continuous story.</p><a href="#lead-demo">Skip the journey. Try a lead <ArrowRight size={16} /></a></div>
      </div>
      <div className={`journey-track${pinned ? ' is-pinned' : ''}${manual ? ' is-manual' : ''}`} ref={trackRef}>
        <div className="journey-panel">
          <div className="journey-panel-content" ref={panelContentRef}>
            <div className="journey-tabs" role="tablist" aria-label="Follow the lead" onKeyDown={tabKeyboard}>
              {storyStages.map((name, index) => <button key={name} role="tab" id={`${id}-tab-${index}`} aria-controls={`${id}-panel`} aria-selected={stage === index} tabIndex={stage === index ? 0 : -1} onClick={() => select(index)}><span>0{index + 1}</span>{name}<i /></button>)}
            </div>
            <div className="journey-body" role="tabpanel" id={`${id}-panel`} aria-labelledby={`${id}-tab-${stage}`}>
              <LeadSpecimen stage={stage} />
              <div className="journey-narrative">
                <span className="journey-numeral" aria-hidden="true">0{stage + 1}</span>
                <p className="journey-eyebrow">{storyStages[stage]} <span>/ {stage + 1} of 6</span></p>
                <h3>{chapters[stage].title}</h3>
                <p className="journey-description">{chapters[stage].description}</p>
                <div className="journey-receipt"><i />{chapters[stage].receipt}</div>
              </div>
            </div>
            <div className="journey-controls">
              <span className="journey-scroll-hint">{pinned && !manual ? <><ArrowDown size={15} /> Scroll to follow the lead</> : 'Illustrative journey · Your records stay yours'}</span>
              <div>{pinned && manual && <button className="journey-follow" onClick={() => { manualRef.current = false; setManual(false); drawRef.current(); }}>Follow scroll <ArrowDown size={14} /></button>}<button onClick={() => select(stage - 1)} disabled={stage === 0} aria-label="Previous journey stage"><ArrowLeft size={16} /><span>Previous</span></button><span className="journey-step-count">{stage + 1} / 6</span><button onClick={() => select(stage + 1)} disabled={stage === 5} aria-label="Next journey stage"><span>Next</span><ArrowRight size={16} /></button></div>
            </div>
          </div>
        </div>
      </div>
      <details className="journey-transcript"><summary>Read the complete journey</summary><ol>{chapters.map((chapter, index) => <li key={chapter.title}><strong>{storyStages[index]} — {chapter.title}</strong><p>{chapter.description}</p></li>)}</ol><p>This is an illustrative lifecycle, including a possible Won outcome. It does not create or change a saved lead, send a message, or schedule an external task.</p></details>
      <div className="journey-handoff"><span>That was Alex’s story.</span><a href="#lead-demo">Now try your lead <ArrowRight size={18} /></a></div>
    </section>
  );
}
