import { qualify, type LeadInput } from './domain';

// Presentation only: never inserted into the workspace.
export const storyInput: LeadInput = {
  name: 'Alex Morgan', company: 'Northline Studio', email: 'alex.morgan@example.com',
  service: 'Website redesign', budget: '£5,000–£10,000', timeline: 'Within 30 days',
};
export const storyLead = { ...storyInput, ...qualify(storyInput), reference: 'G / 001', owner: 'Jamie Lee' };
export const storyStages = ['Capture', 'Qualify', 'Score', 'Route', 'Follow up', 'Convert'] as const;
export const routing = {
  width: 1280, height: 300, gates: [395, 530, 665],
  main: [[-80, 190], [170, 190], [290, 150], [810, 150], [900, 150], [990, 65], [1250, 65]],
  secondary: [[-80, 65], [135, 65], [290, 150]],
  third: [[-80, 280], [135, 280], [290, 150]],
  discovery: [[900, 150], [990, 200], [1280, 200]],
  nurture: [[900, 150], [990, 270], [1280, 270]],
} as const;
export function routePath(points: readonly (readonly number[])[]) {
  return points.map(([x, y], i) => `${i ? 'L' : 'M'}${x} ${y}`).join(' ');
}
export function leadPosition(progress: number) {
  const stops = [[0, -30, 190], [.12, 230, 170], [.27, 395, 150], [.4, 530, 150], [.53, 665, 150], [.66, 810, 150], [.74, 900, 150], [.86, 990, 65], [1, 1150, 65]];
  const p = Math.max(0, Math.min(1, progress));
  const end = stops.findIndex((stop) => stop[0] >= p);
  const b = stops[Math.max(1, end)];
  const a = stops[Math.max(0, end - 1)];
  const t = (p - a[0]) / (b[0] - a[0]);
  return { x: a[1] + (b[1] - a[1]) * t, y: a[2] + (b[2] - a[2]) * t };
}

export type HeroClock = {
  getSnapshot: () => number;
  subscribe: (listener: (progress: number) => void) => () => void;
};
