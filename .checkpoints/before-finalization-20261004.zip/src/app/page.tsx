import { MarketingShell, FinalCTA } from '@/components/marketing/shell';
import { Hero } from '@/components/marketing/hero';
import {
  Problem,
  PipelineSection,
  AnalyticsSection,
  SolutionsSelector,
  IntegrationUniverse,
  Pricing,
  Philosophy,
} from '@/components/marketing/sections';
import { OpportunityPreview } from '@/components/product/opportunity-preview';
import { LeadCapture } from '@/components/product/lead-capture';
import { AutomationSection } from '@/components/product/automation';
export const metadata = { alternates: { canonical: '/' } };
export default function Home() {
  return (
    <MarketingShell>
      <Hero />
      <Problem />
      <LeadCapture />
      <OpportunityPreview />
      <AutomationSection />
      <PipelineSection />
      <AnalyticsSection />
      <SolutionsSelector />
      <IntegrationUniverse />
      <Philosophy />
      <Pricing />
      <FinalCTA />
    </MarketingShell>
  );
}
